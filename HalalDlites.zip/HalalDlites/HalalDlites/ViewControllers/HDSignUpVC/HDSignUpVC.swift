//
//  HDSignUpVC.swift
//  HalalDlites
//
//  Created by Yogesh on 30/01/17.
//  Copyright © 2017 CCS Group. All rights reserved.
//

import UIKit
import Alamofire
import FormToolbar

class HDSignUpVC: UIViewController ,UITextViewDelegate,UITextFieldDelegate
{
    
    @IBOutlet weak var ScrollView: UIScrollView!
    @IBOutlet weak var btnPhone: UIButton!
    @IBOutlet weak var btnEmail: UIButton!
    @IBOutlet weak var imgSeparator: UIImageView!
    @IBOutlet weak var imgIndicator: UIImageView!
    
    @IBOutlet weak var ViewEmailPhone: HDCommonBorderTextField!
    @IBOutlet weak var txtCode: UITextField!
    
    @IBOutlet weak var lblPhoneSeparator: UILabel!
    
    @IBOutlet weak var txtPhone: UITextField!
    @IBOutlet weak var btnNext: HDCommonGreenButton!
   
    @IBOutlet weak var textViewTerms: UITextView!
    @IBOutlet weak var lblLine: UILabel!
    @IBOutlet weak var btnAl: UIButton!
   
    
    
    
    private lazy var toolbar: FormToolbar = {
        return FormToolbar(inputs: self.inputs)
    }()
    
    private var inputs: [FormInput] {
        return [txtCode, txtPhone]
    }
    
    private weak var activeInput: FormInput?
    
    override func loadView() {
        super.loadView()
       
        //txtCode.delegate = self
        //txtPhone.delegate = self
    }
    
    override func viewDidLayoutSubviews()
    {
        super.viewDidLayoutSubviews();
        
        DispatchQueue.main.async {
            self.ScrollView.contentSize = CGSize(width: self.view.frame.size.width , height:self.textViewTerms.frame.origin.y + self.textViewTerms.frame.size.height)
        }
    }
   
       
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        let dict = HDCommonMethodModel().methodToSetCountryCodeBasedOnCarier()
        print(dict)
       
        txtCode.text = "+" + String(dict.object(forKey: "country_code") as! Int)
        
        setLayout()
      
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: .UIKeyboardWillHide, object: nil)
       self.txtPhone.delegate = self
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: - UITextFields Delegate Methods
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if textField == txtPhone
        {
            if txtPhone.placeholder == "Phone Number"
            {
           
                let currentCharacterCount = txtPhone.text?.characters.count ?? 0
                if (range.length + range.location > currentCharacterCount)
                {
                    return false
                }
                let newLength = currentCharacterCount + string.characters.count - range.length
                return newLength <= 15
            }
            else if txtPhone.placeholder == "Email Address"
            {
                let currentCharacterCount = txtPhone.text?.characters.count ?? 0
                if (range.length + range.location > currentCharacterCount)
                {
                    return false
                }
                let newLength = currentCharacterCount + string.characters.count - range.length
                return newLength <= 50
            }
        }
        
        else if textField == txtCode
        {
            if (string == "" && txtCode.text == "+")
            {
                return false
            }
            if(range.location == 0)
            {
                return false
            }
            let currentCharacterCount = txtCode.text?.characters.count ?? 0
            if (range.length + range.location > currentCharacterCount)
            {
                return false
            }
            let newLength = currentCharacterCount + string.characters.count - range.length
            return newLength <= 4
        }
        
        return true
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        toolbar.update()
        activeInput = textField
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if (textField == txtPhone)
        {
            self.view.endEditing(true)
            return false
        }
        else
        {
        toolbar.goForward()
        return true
        }

    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        toolbar.update()
        activeInput = textView
    }

    
    // MARK: - User Defined Methods
    
    func setLayout()
    {
        Constant().CENTERNAVTITLE(self.navigationItem, "SIGN UP")
        Constant().LEFTBACKBUTTON(navItem: self.navigationItem, ref: self)
        
        btnPhone.titleLabel?.font = Constant.FONT.medium.of(size: 18)
        btnEmail.titleLabel?.font = Constant.FONT.medium.of(size: 18)
        txtCode.font=Constant.FONT.medium.of(size: 13)
        txtPhone.font = Constant.FONT.medium.of(size: 13)
        btnNext.titleLabel?.font = Constant.FONT.medium.of(size: 15)
        textViewTerms.font = Constant.FONT.medium.of(size: 12)
        btnAl.titleLabel?.font = Constant.FONT.medium.of(size: 12)
        
        btnPhone.setTitleColor(Constant.COLOR.aColor_Green, for: .normal)
        btnEmail.setTitleColor(Constant.COLOR.aColor_Grey, for: .normal)
        btnAl.setTitleColor(Constant.COLOR.aColor_Grey, for: .normal)
        lblPhoneSeparator.backgroundColor = Constant.COLOR.aColor_Grey
        lblLine.backgroundColor = Constant.COLOR.aColor_Grey
        
        let aAttrStrTermsPrivacy = NSMutableAttributedString(string:"By signing up,you agree to the Terms and Conditions and the Privacy Policy. ")
        
        aAttrStrTermsPrivacy.setAttributes([NSForegroundColorAttributeName : (Constant.COLOR.aColor_Grey)], range: NSRange(location:0,length:30))
        aAttrStrTermsPrivacy.setAttributes([NSForegroundColorAttributeName : (Constant.COLOR.aColor_Grey)], range: NSRange(location:52,length:8))
        
        aAttrStrTermsPrivacy.addAttribute(NSLinkAttributeName, value: "http://juzfood.com/index.php/page/terms", range:NSMakeRange(31,20))
        aAttrStrTermsPrivacy.addAttribute(NSLinkAttributeName, value: "http://juzfood.com/index.php/page/privacy", range: aAttrStrTermsPrivacy.mutableString.range(of: "Privacy Policy."))
        textViewTerms.attributedText = aAttrStrTermsPrivacy
        textViewTerms.linkTextAttributes = [NSForegroundColorAttributeName : Constant.COLOR.aColor_Green]
    }
    
   
    @IBAction func btnClicked(_ sender: Any)
    {
        let aBtnClicked = sender as! UIButton
        
        if aBtnClicked == btnPhone
        {
            self.toolbar = FormToolbar(inputs: [txtCode, txtPhone])

            btnPhone.setTitleColor(Constant.COLOR.aColor_Green, for: .normal)
            btnEmail.setTitleColor(Constant.COLOR.aColor_Grey, for: .normal)
            
            imgIndicator.frame = CGRect(origin: CGPoint(x: imgSeparator.frame.origin.x,y :imgSeparator.frame.origin.y), size: CGSize(width: imgSeparator.frame.size.width/2, height: imgIndicator.frame.size.height))
            
            txtPhone.frame = (frame : CGRect(x: ViewEmailPhone.frame.origin.x + lblPhoneSeparator.frame.origin.x + 8,
                                             y: ViewEmailPhone.frame.origin.y,
                                             width:  ViewEmailPhone.frame.size.width - 65,
                                             height: txtPhone.frame.size.height))
            
            txtPhone.placeholder = "Phone Number";
            txtPhone.text = ""
            txtPhone.keyboardType = UIKeyboardType.phonePad
            txtCode.isHidden = false
            lblPhoneSeparator.isHidden = false
            
        }
           
        else if aBtnClicked == btnEmail
        {
            self.toolbar = FormToolbar(inputs: [txtPhone])
            
            txtPhone.resignFirstResponder()
            
            btnEmail.setTitleColor(Constant.COLOR.aColor_Green, for: .normal)
            btnPhone.setTitleColor(Constant.COLOR.aColor_Grey, for: .normal)
            
            imgIndicator.translatesAutoresizingMaskIntoConstraints = true
           
            imgIndicator.frame = CGRect(origin: CGPoint(x: btnEmail.frame.origin.x,y :imgSeparator.frame.origin.y), size: CGSize(width: imgSeparator.frame.size.width/2, height: imgIndicator.frame.size.height))
            txtPhone.translatesAutoresizingMaskIntoConstraints = true

            txtPhone.frame = (frame : CGRect(x:ViewEmailPhone.frame.origin.x + 10,
                                             y:ViewEmailPhone.frame.origin.y,
                                             width:  ViewEmailPhone.frame.size.width - 20,
                                             height: txtPhone.frame.size.height))
            txtPhone.placeholder = "Email Address"
            txtPhone.text = ""
            txtPhone.keyboardType = UIKeyboardType.emailAddress
            
            txtCode.isHidden = true
            lblPhoneSeparator.isHidden = true
        }
        else if aBtnClicked == btnNext
        {
            if txtPhone.placeholder == "Phone Number"
            {
                
                
                //check for empty
                if((txtCode.text?.isEmpty)! || (txtPhone.text?.isEmpty)!)
                {
                    //display error message
                    AlertBar.show(.info, message: "All Fields are required")
                    return
                }
                do
                {
                    //call sms create api
                    DispatchQueue.main.async
                    {
                    AppDelegate().getProgressInstance().showProgressView(self.view)
                    }

                    var RemovePlus = "\(txtCode.text!)"
                    RemovePlus.remove(at: RemovePlus.startIndex)
                        
                       let aDictParams : NSMutableDictionary = ["country_code": RemovePlus , "phone_number":txtPhone.text!, "used_for":"1"]
                        
                        DispatchQueue.global(qos:.default).async {
                            
                            HDWebServiceModal().callWebservice(aStrUrl: "sms/create", aMutDictParams: aDictParams, ref: self, aStrTag: "SMSCREATE")
                        }
               
                }
                
            }
            else if txtPhone.placeholder == "Email Address"
            {
                
                if((txtPhone.text?.isEmpty)!)
                {
                    //display error message
                    AlertBar.show(.info, message: "Enter Email Address")
                    return
                }
                
                
                do
                {
                    
                    if HDCommonMethodModel().methodToValidateEmailAndWebsite(strEmailOrWebsite: txtPhone.text!, type: "email")
                    {
                    //call sms create api
                    DispatchQueue.main.async
                        {
                            AppDelegate().getProgressInstance().showProgressView(self.view)
                    }
                    
                    
                    let aDictParams : NSMutableDictionary = ["email":txtPhone.text!, "used_for":"1"]
                    DispatchQueue.global(qos:.default).async {
                        HDWebServiceModal().callWebservice(aStrUrl: "sms/create", aMutDictParams: aDictParams, ref: self, aStrTag: "SendEmail")
                    }
                    }
                    else
                    {
                        txtPhone.text = ""
                        AlertBar.show(.info, message: "Email Id is not valid")
                        return
                    }
                    
                }
            }
        }
            
            
        else if aBtnClicked == btnAl
        {
            self.navigationController!.popViewController(animated: true)
        }
    }
    
    func btnPopTapped()
    {
        self.navigationController!.popViewController(animated: true)
    }


    
    @objc func keyboardWillShow(_ notification: Notification) {
        let userInfo: NSDictionary = notification.userInfo! as NSDictionary
        let keyboardInfo = userInfo[UIKeyboardFrameBeginUserInfoKey] as! NSValue
        let keyboardSize = keyboardInfo.cgRectValue.size
        let contentInsets = UIEdgeInsets(top: 0, left: 0, bottom: keyboardSize.height + 90.0, right: 0)
        ScrollView.contentInset = contentInsets
        ScrollView.scrollIndicatorInsets = contentInsets
    }
    
    @objc func keyboardWillHide(_ notification: Notification) {
        ScrollView.contentInset = .zero
        ScrollView.scrollIndicatorInsets = .zero
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    // MARK: - UITextview Delegate Methods

    public func textView(_ textView: UITextView, shouldInteractWith URL: URL, in characterRange: NSRange) -> Bool
    {
        if(URL.absoluteString == "http://juzfood.com/index.php/page/terms")
        {
            let myAlert = UIAlertController(title: "Terms", message: nil, preferredStyle: UIAlertControllerStyle.alert)
            myAlert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            self.present(myAlert, animated: true, completion: nil)
        }
        else if (URL.absoluteString == "http://juzfood.com/index.php/page/privacy")
        {
            let myAlert = UIAlertController(title: "Conditions", message: nil, preferredStyle: UIAlertControllerStyle.alert)
            myAlert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            self.present(myAlert, animated: true, completion: nil)
        }
        return false
    }
    
    //MARK: -WebService Response
    
    func getWebserviceResponse(aDictResponse: NSDictionary, aStrTag: String)
    {
       // print("Response:::\(aDictResponse)")
        DispatchQueue.main.async
        {
            AppDelegate().getProgressInstance().hideProgressView()
        }

        if aStrTag == Constant.messages.KMsgNoInternet
        {
            AlertBar.show(.error, message: "No Internet Connection")
        }
        
        if aStrTag == "SMSCREATE"
        {
            if ((aDictResponse.object(forKey: "result") as! NSDictionary).object(forKey: "status") as! NSString).isEqual(to: "success")
            {
              
                let aDictResponse :NSDictionary = (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "data")as! NSDictionary
                
                let aObj : HDVerificationVC = self.storyboard!.instantiateViewController(withIdentifier: "HDVerificationVC") as! HDVerificationVC
                
                
                if txtPhone.placeholder == "Phone Number"
                {
                    aObj.dictVerFromSignUp = ["CountryCode" : txtCode.text! ,"PhoneNumber" : txtPhone.text!, "sms_sent" : aDictResponse.value(forKey: "sms_sent")!, "verification_code" : aDictResponse.value(forKey: "verification_code")! , "isEmail" : "0" ]
                }
                else
                {
                    aObj.dictVerFromSignUp = ["emailId" : txtPhone.text!, "sms_sent" : aDictResponse.value(forKey: "sms_sent")!, "verification_code" : aDictResponse.value(forKey: "verification_code")! , "isEmail" : "1" ]
                }
                
                self.navigationController!.pushViewController(aObj, animated: true)
               
            }
            else
            {
                AlertBar.show(.error, message: (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "message") as! String)

             print("error")
            }
        }
      
        if aStrTag == "SendEmail"
        {
            if ((aDictResponse.object(forKey: "result") as! NSDictionary).object(forKey: "status") as! NSString).isEqual(to: "success")
            {
                
                let aDictResponse :NSDictionary = (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "data")as! NSDictionary
                print("Response:::\(aDictResponse)")
                let aObj : HDVerificationVC = self.storyboard!.instantiateViewController(withIdentifier: "HDVerificationVC") as! HDVerificationVC
                aObj.dictVerFromSignUp = ["emailId" : txtPhone.text!, "sms_sent" : aDictResponse.value(forKey: "sms_sent")!, "verification_code" : aDictResponse.value(forKey: "verification_code")! , "isEmail" : "1" ]
                self.navigationController!.pushViewController(aObj, animated: true)
                
               
            }
            else
            {
                AlertBar.show(.error, message: (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "message") as! String)

                print("error")
            }
        }
    }
   }
/*
  aObj.dictVerFromSignUp = ["email_phone" : txtCode.text! + " " + txtPhone.text!, "sms_sent" : aDictResponse.value(forKey: "sms_sent")!, "verification_code" : aDictResponse.value(forKey: "verification_code")!]*/
