//
//  HDProfileVC.swift
//  HalalDlites
//
//  Created by user11 on 4/7/17.
//  Copyright © 2017 CCS Group. All rights reserved.
//

import UIKit
import FormToolbar

class HDProfileVC: UIViewController,UITextFieldDelegate,UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate
{
    
    @IBOutlet weak var ScrollView: UIScrollView!
    @IBOutlet weak var btnProfilePhoto: UIButton!
    @IBOutlet weak var btnChangePhoto: UIButton!
    @IBOutlet weak var ImgIconName: UIImageView!
    @IBOutlet weak var txtName: HDCommonBottomBorderTxtField!
    @IBOutlet weak var ImgIconPhone: UIImageView!
    @IBOutlet weak var txtcode: HDCommonBottomBorderTxtField!
    @IBOutlet weak var txtPhone: HDCommonBottomBorderTxtField!
    @IBOutlet weak var ImgIconEmail: UIImageView!
    @IBOutlet weak var txtEmail: HDCommonBottomBorderTxtField!
    
    @IBOutlet weak var btnChangePwd: HDCommonGreenButton!
    let imagePicker = UIImagePickerController()
  
    private lazy var toolbar: FormToolbar = {
        return FormToolbar(inputs: self.inputs)
    }()
    
    private var inputs: [FormInput] {
        return [ txtName,txtcode,txtPhone,txtEmail ]
    }
    
    private weak var activeInput: FormInput?
    
    override func loadView()
    {
        super.loadView()
        txtName.delegate = self
        txtcode.delegate = self
        txtPhone.delegate = self
        txtEmail.delegate = self
    }
    override func viewDidLayoutSubviews()
    {
        DispatchQueue.main.async {
           
            self.ScrollView.contentSize = CGSize(width: self.view.frame.size.width , height:self.txtEmail.frame.origin.y + self.txtEmail.frame.size.height )
        }
    }

    override func viewDidLoad()
    {
        super.viewDidLoad()
        setLayout()
        
        self.txtcode.text = "+" + ((UserDefaults.standard.value(forKey: "RegisteredUserProfile")! as AnyObject).value(forKey: "country_code")! as? String)!
        self.txtPhone.text = (UserDefaults.standard.value(forKey: "RegisteredUserProfile")! as AnyObject).value(forKey: "phone_number")! as? String
        
        self.txtEmail.text = (UserDefaults.standard.value(forKey: "RegisteredUserProfile")! as AnyObject).value(forKey: "email")! as? String

        let picURL = (UserDefaults.standard.value(forKey: "RegisteredUserProfile")! as AnyObject).value(forKey: "photo")! as? String
//        let url = NSURL(string : picURL!)
//        if let data = NSData(contentsOf : url! as URL)
//            
//        {
//            self.btnProfilePhoto.setImage(UIImage(data : data as Data), for: UIControlState.normal)
//            //self.btnProfilePhoto.imageView?.image = UIImage(data : data as Data)
//        }
        LazyImage.show(imageView: self.btnProfilePhoto.imageView!, url: picURL)
        
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: .UIKeyboardWillHide, object: nil)
        
        print((UserDefaults.standard.value(forKey: "RegisteredUserProfile") as AnyObject))
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
       
    }
    //MARK: - TextField delegate Methods
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if textField == txtPhone
        {
            
            let currentCharacterCount = txtPhone.text?.characters.count ?? 0
            if (range.length + range.location > currentCharacterCount)
            {
                return false
            }
            let newLength = currentCharacterCount + string.characters.count - range.length
            return newLength <= 15
            
        }
        else if textField == txtEmail
        {
            let currentCharacterCount = txtEmail.text?.characters.count ?? 0
            if (range.length + range.location > currentCharacterCount)
            {
                return false
            }
            let newLength = currentCharacterCount + string.characters.count - range.length
            return newLength <= 50
        }
        else if textField == txtcode
        {
            if (string == "" && txtcode.text == "+")
            {
                return false
            }
            if(range.location == 0)
            {
                return false
            }
            let currentCharacterCount = txtcode.text?.characters.count ?? 0
            if (range.length + range.location > currentCharacterCount)
            {
                return false
            }
            let newLength = currentCharacterCount + string.characters.count - range.length
            return newLength <= 4
        }
        
        return true
    }

    func textFieldDidBeginEditing(_ textField: UITextField)
    {
        toolbar.update()
        activeInput = textField
        
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        toolbar.goForward()
        return true
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        toolbar.update()
        activeInput = textView
    }
    
    @objc func keyboardWillShow(_ notification: Notification) {
        let userInfo: NSDictionary = notification.userInfo! as NSDictionary
        let keyboardInfo = userInfo[UIKeyboardFrameBeginUserInfoKey] as! NSValue
        let keyboardSize = keyboardInfo.cgRectValue.size
        let contentInsets = UIEdgeInsets(top: 0, left: 0, bottom: keyboardSize.height + 90.0, right: 0)
        ScrollView.contentInset = contentInsets
        ScrollView.scrollIndicatorInsets = contentInsets
    }
    
    @objc func keyboardWillHide(_ notification: Notification) {
        ScrollView.contentInset = .zero
        ScrollView.scrollIndicatorInsets = .zero
    }
    deinit
    {
        NotificationCenter.default.removeObserver(self)
    }

    
    @IBAction func btnChangePwd(_ sender: Any)
    {
        
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "HDChangePwd"))! as UIViewController, animated: true)
        
    }
    @IBAction func btnChangeProfilePhoto(_ sender: Any)
    {
        let alert = UIAlertController(title: nil, message: nil, preferredStyle: UIAlertControllerStyle.actionSheet)
        let CameraRoll = UIAlertAction(title: "Camera Roll", style:UIAlertActionStyle.default,handler:
            { (ACTION :UIAlertAction!)in
                if UIImagePickerController.isSourceTypeAvailable(.camera)
                {
                    
                    self.imagePicker.delegate = self
                    self.imagePicker.allowsEditing = false
                    self.imagePicker.sourceType = .camera
                    self.imagePicker.mediaTypes = UIImagePickerController.availableMediaTypes(for: .camera)!
                    self.present(self.imagePicker, animated: true, completion: nil)
                }
                else {
                    self.noCameraAlert()
                }
        })
        let ChoosePhoto = UIAlertAction(title: "Choose Photo", style: UIAlertActionStyle.default,handler:
            { (ACTION :UIAlertAction!)in
                
                self.imagePicker.delegate = self
                self.imagePicker.allowsEditing = false
                self.imagePicker.sourceType = .photoLibrary
                
                self.navigationController?.present(self.imagePicker, animated: true, completion: nil)
                
        })
        
        let cancelButton = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel)
        
        alert.addAction(CameraRoll)
        alert.addAction(ChoosePhoto)
        alert.addAction(cancelButton)
        
        self.present(alert, animated: true, completion: nil)
    }
    
    
    func noCameraAlert() {
        let alertController = UIAlertController(title: "Error", message: "No camera available.", preferredStyle: .alert)
        let okayAction = UIAlertAction(title: "Okay", style: .default, handler: nil)
        alertController.addAction(okayAction)
        present(alertController, animated: true, completion: nil)
    }
    //MARK: -ImagePicker Delegate methods
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let chosenImage = info[UIImagePickerControllerOriginalImage] as! UIImage
        btnProfilePhoto.setImage(chosenImage, for: UIControlState.normal)
        
        dismiss(animated: true, completion: nil)
    }

    
    //MARK: - User Defined Methods
    func setLayout()
    {
        Constant().CENTERNAVTITLE(self.navigationItem, "PROFILE")
        Constant().LEFTDRAWERBUTTON(navItem: self.navigationItem, ref: self)
        Constant().RIGHTDONEBUTTON(navItem: self.navigationItem, ref: self)
        btnChangePhoto.setTitleColor(Constant.COLOR.aColor_Black, for: .normal)
        ImgIconName.image = UIImage(named:"profileUser.png")
        txtName.borderStyle = UITextBorderStyle.none
        ImgIconPhone.image = UIImage(named:"call.png")
        txtcode.borderStyle = UITextBorderStyle.none
        txtPhone.borderStyle = UITextBorderStyle.none
        ImgIconEmail.image = UIImage(named:"email.png")
        txtEmail.borderStyle = UITextBorderStyle.none
    }
    func btnDrawerTapped()
    {
        HDDrawerMenuOptionVC.sharedInstance.slidingPanel.toggleLeftSlidingPanel()
        
    }
    func btnDoneTapped()
    {
        
        
        //check for empty
        if((txtName.text?.isEmpty)! || (txtcode.text?.isEmpty)! || (txtPhone.text?.isEmpty)! || (txtEmail.text?.isEmpty)!)
        {
            //display error message
            AlertBar.show(.info, message: "All Fields are required")
            return
        }
        do
        {
            //call sms create api
            
            if HDCommonMethodModel().methodToValidateEmailAndWebsite(strEmailOrWebsite: txtEmail.text!, type: "email")
            {
                DispatchQueue.main.async
                    {
                        AppDelegate().getProgressInstance().showProgressView(self.view)
                }

                var RemovePlus = "\(txtcode.text!)"
                RemovePlus.remove(at: RemovePlus.startIndex)
                let aDictParams : NSMutableDictionary = ["user_id":((UserDefaults.standard.value(forKey: "RegisteredUserProfile")!) as AnyObject).value(forKey: "user_id")! ,"login_token":((UserDefaults.standard.value(forKey: "RegisteredUserProfile")!) as AnyObject).value(forKey: "login_token")!,"full_name":txtName.text!,"email":txtEmail.text!,"country_code":RemovePlus,"phone_number":txtPhone.text!]
            
            
            let image : NSMutableDictionary = ["photo" : (btnProfilePhoto.imageView?.image)! as UIImage , "key" : "photo"]
                let aArrImages : NSMutableArray = ([image])
            
                DispatchQueue.global(qos:.default).async
                {
                    HDWebServiceModal().callMultipartWebservice(aStrUrl: "user/edit", aMutDictParams: aDictParams, aMutArrImages: aArrImages, ref: self, aStrTag: "EditProfile")
                }
            }
            else
            {
                txtEmail.text = ""
                AlertBar.show(.info, message: "Email Id is not valid")
                return
            }
            
        }
    }
   
    //MARK: -WebService Response
    
    func getWebserviceResponse(aDictResponse: NSDictionary, aStrTag: String)
    {
        // print("Response:::\(aDictResponse)")
        DispatchQueue.main.async
        {
                AppDelegate().getProgressInstance().hideProgressView()
        }
        
        if aStrTag == Constant.messages.KMsgNoInternet
        {
            AlertBar.show(.error, message: "No Internet Connection")
        }
        
        if aStrTag == "EditProfile"
        {
            if ((aDictResponse.object(forKey: "result") as! NSDictionary).object(forKey: "status") as! NSString).isEqual(to: "success")
            {
                AlertBar.show(.info, message: (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "message") as! String)
                let aDictResponse :NSDictionary = (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "data")as! NSDictionary


                let aDictParams : NSMutableDictionary = ["country_code": txtcode.text!,
                                                         "device_token":(UserDefaults.standard.value(forKey: "RegisteredUserProfile") as! NSMutableDictionary).value(forKey: "device_token")! ,
                                                         "device_type":(UserDefaults.standard.value(forKey: "RegisteredUserProfile") as! NSMutableDictionary).value(forKey: "device_type")! ,
                                                         "email":txtEmail.text! ,
                                                         "full_name":txtName.text! ,
                                                         "is_login":(UserDefaults.standard.value(forKey: "RegisteredUserProfile") as! NSMutableDictionary).value(forKey: "is_login")! ,
                                                         "last_login_date":(UserDefaults.standard.value(forKey: "RegisteredUserProfile") as! NSMutableDictionary).value(forKey: "last_login_date")! ,
                                                         "lat":(UserDefaults.standard.value(forKey: "RegisteredUserProfile") as! NSMutableDictionary).value(forKey: "lat")! ,
                                                         "lng":(UserDefaults.standard.value(forKey: "RegisteredUserProfile") as! NSMutableDictionary).value(forKey: "lng")! ,
                                                         "login_token":(UserDefaults.standard.value(forKey: "RegisteredUserProfile") as! NSMutableDictionary).value(forKey: "login_token")! ,
                                                         "login_with":(UserDefaults.standard.value(forKey: "RegisteredUserProfile") as! NSMutableDictionary).value(forKey: "login_with")! ,
                                                         "phone_number":txtPhone.text! ,
                                                         "photo":aDictResponse.object(forKey: "photo")! ,
                                                         "role":(UserDefaults.standard.value(forKey: "RegisteredUserProfile") as! NSMutableDictionary).value(forKey: "role")! ,
                                                         "user_id":(UserDefaults.standard.value(forKey: "RegisteredUserProfile") as! NSMutableDictionary).value(forKey: "user_id")!]

                UserDefaults.standard.set(aDictParams , forKey :"RegisteredUserProfile")

                
//                (UserDefaults.standard.value(forKey: "RegisteredUserProfile") as! NSMutableDictionary).setValue(aDictResponse.value(forKey: "photo"), forKey: "photo")
//                (UserDefaults.standard.value(forKey: "RegisteredUserProfile") as! NSMutableDictionary).setValue(aDictResponse.value(forKey: "country_code"), forKey: "country_code")
//                    
//                (UserDefaults.standard.value(forKey: "RegisteredUserProfile") as! NSMutableDictionary).setValue(aDictResponse.value(forKey: "phone_number"), forKey: "phone_number")
//                    
//                (UserDefaults.standard.value(forKey: "RegisteredUserProfile") as! NSMutableDictionary).setValue(aDictResponse.value(forKey: "email"), forKey: "email")
//                    
//                (UserDefaults.standard.value(forKey: "RegisteredUserProfile") as! NSMutableDictionary).setValue(aDictResponse.value(forKey: "full_name"), forKey: "full_name")


                //(UserDefaults.standard.value(forKey: "RegisteredUserProfile") as AnyObject)
                //(UserDefaults.standard.value(forKey: "RegisteredUserProfile") as AnyObject).replaceObject(at: intEditProfile, with: aDictParams)
                
//                let aDictParams : NSMutableDictionary = ["favourite": "0", "photo": ((mutPromotionList.object(at: intFavouriteRow) as! NSDictionary).value(forKey: "photo") as! NSString) , "promotion_count":((mutPromotionList.object(at: intFavouriteRow) as! NSDictionary).value(forKey: "promotion_count") as! NSString)  , "promotion_id": ((mutPromotionList.object(at: intFavouriteRow) as! NSDictionary).value(forKey: "promotion_id") as! NSString) , "title": ((mutPromotionList.object(at: intFavouriteRow) as! NSDictionary).value(forKey: "title") as! NSString)]
//                
//                mutPromotionList.replaceObject(at: intFavouriteRow, with: aDictParams)
                
                
                
            }
            else
            {
                AlertBar.show(.error, message: (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "message") as! String)

                print("profile does not edited.")
            }
        }
        
    }

}
