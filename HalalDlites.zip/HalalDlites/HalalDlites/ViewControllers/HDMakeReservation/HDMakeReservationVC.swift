//
//  HDMakeReservationVC.swift
//  HalalDlites
//
//  Created by user11 on 2/27/17.
//  Copyright © 2017 CCS Group. All rights reserved.
//

import UIKit
import FormToolbar

class HDMakeReservationVC: UIViewController,UITextFieldDelegate,UITextViewDelegate,UIPickerViewDelegate,UIPickerViewDataSource
{
    

    var mutRestProfile  : NSDictionary = [:]
    var arrNumOfAdultsChild = ["0","1","2","3","4","5","6","7","8","9"]
    var arrMr = ["Mr","Ms","Mrs"]
    
    var AdultsPickerView: UIPickerView = UIPickerView()
    var childrenPickerView : UIPickerView = UIPickerView()
    var MrPickerView: UIPickerView = UIPickerView()
    

    @IBOutlet weak var ScrollView: UIScrollView!
   
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblNoOfDinner: UILabel!
    @IBOutlet weak var lblTime: UILabel!
    @IBOutlet weak var lblYourName: UILabel!
    @IBOutlet weak var lblPhoneNo: UILabel!
    @IBOutlet weak var lblSeparator: UILabel!
    @IBOutlet weak var lblNotes: UILabel!
    @IBOutlet weak var lblCharacters: UILabel!
    
    
    
   
    @IBOutlet weak var txtFieldDate: HDCommonBorderTextField!
    @IBOutlet weak var txtFieldAdults: HDCommonBorderTextField!
    @IBOutlet weak var txtFieldChildren: HDCommonBorderTextField!
    @IBOutlet weak var txtFieldTime: HDCommonBorderTextField!
    @IBOutlet weak var txtFieldMr: HDCommonBorderTextField!
    @IBOutlet weak var txtFieldFirstName: HDCommonBorderTextField!
    @IBOutlet weak var txtFieldLastName: HDCommonBorderTextField!
    @IBOutlet weak var txtFieldCountryCode: UITextField!
    @IBOutlet weak var txtFieldPhoneNo: UITextField!
    @IBOutlet weak var TextViewNote: HDCommonTextView!
    
    @IBOutlet weak var btnBookNow: HDCommonGreenButton!
    
    
    private lazy var toolbar: FormToolbar = {
        return FormToolbar(inputs: self.inputs)
    }()
    
    private var inputs: [FormInput] {
        return [ txtFieldDate, txtFieldAdults, txtFieldChildren, txtFieldTime , txtFieldMr , txtFieldFirstName, txtFieldLastName , txtFieldCountryCode , txtFieldPhoneNo , TextViewNote]
    }

    private weak var activeInput: FormInput?
    
    override func loadView() {
        super.loadView()
        txtFieldDate.delegate = self
        txtFieldAdults.delegate = self
        txtFieldChildren.delegate = self
        txtFieldTime.delegate = self
        txtFieldMr.delegate = self
        txtFieldFirstName.delegate = self
        txtFieldLastName.delegate = self
        txtFieldCountryCode.delegate = self
        txtFieldPhoneNo.delegate = self
        TextViewNote.delegate = self
    }

    override func viewDidLayoutSubviews()
    {
        DispatchQueue.main.async {
            //self.ScrollView.contentSize = CGSize(width: self.view.frame.size.width , height:1000)
            self.ScrollView.contentSize = CGSize(width: self.view.frame.size.width , height:self.btnBookNow.frame.origin.y + self.btnBookNow.frame.size.height + 20)
        }
    }


    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        setLayout()
        
        self.AdultsPickerView.isHidden = true
        self.AdultsPickerView.delegate = self
        self.AdultsPickerView.tag = 1
        self.AdultsPickerView.dataSource = self
        self.AdultsPickerView.frame = CGRect(x:0, y:self.view.frame.size.height - 216, width:self.view.frame.size.width, height:216)
        
        self.childrenPickerView.isHidden = true
        self.childrenPickerView.delegate = self
        self.childrenPickerView.tag = 2
        self.childrenPickerView.dataSource = self
        self.childrenPickerView.frame = CGRect(x:0, y:self.view.frame.size.height - 216, width:self.view.frame.size.width, height:216)

        self.MrPickerView.isHidden = true
        self.MrPickerView.delegate = self
        self.MrPickerView.tag = 3
        self.MrPickerView.dataSource = self
        self.MrPickerView.frame = CGRect(x:0, y:self.view.frame.size.height - 216, width:self.view.frame.size.width, height:216)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: .UIKeyboardWillHide, object: nil)
        
        
        print(UserDefaults.standard.value(forKey: "RegisteredUserProfile")!)
        self.txtFieldCountryCode.text = "+" + ((UserDefaults.standard.value(forKey: "RegisteredUserProfile")! as AnyObject).value(forKey: "country_code")! as? String)!
        self.txtFieldPhoneNo.text = (UserDefaults.standard.value(forKey: "RegisteredUserProfile")! as AnyObject).value(forKey: "phone_number")! as? String
        
        

    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int
    {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView.tag == 1
        {
            return arrNumOfAdultsChild.count
        }
        if pickerView.tag == 2
        {
            return arrNumOfAdultsChild.count
        }
        if pickerView.tag == 3
        {
            return arrMr.count
        }
        return 0
    }
    
//    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?
//    {
//        if pickerView.tag == 1
//        {
//        return arrNumOfAdultsChild[row]
//        }
//        if pickerView.tag == 2
//        {
//        return arrNumOfAdultsChild[row]
//        }
//        if pickerView.tag == 3
//        {
//        return arrMr[row]
//        }
//        return nil
//   }
    
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView
    {
        var label: UILabel
        if let view = view as? UILabel
        {
            label = view
        }
        else
        {
            label = UILabel()
        }
        label.textColor = .black
        label.textAlignment = .center
        label.font = UIFont(name: "SanFranciscoText-Light", size: 18)
        // where data is an Array of String
        if pickerView.tag == 1
        {
            label.text = arrNumOfAdultsChild[row]
        }
        if pickerView.tag == 2
        {
            label.text = arrNumOfAdultsChild[row]
        }
        if pickerView.tag == 3
        {
            label.text = arrMr[row]
        }
        return label
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        if pickerView.tag == 1
        {
            txtFieldAdults.text = arrNumOfAdultsChild[row]
            txtFieldAdults.resignFirstResponder()
        }
        if pickerView.tag == 2
        {
            txtFieldChildren.text = arrNumOfAdultsChild[row]
            txtFieldChildren.resignFirstResponder()
        }
        if pickerView.tag == 3
        {
            txtFieldMr.text = arrMr[row]
            txtFieldMr.resignFirstResponder()
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, widthForComponent component: Int) -> CGFloat {
        return 36.0
    }
    
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 36.0
    }

    //MARK: - TextField delegate Methods
    func textFieldDidBeginEditing(_ textField: UITextField)
    {
        if textField == txtFieldDate
        {
            let datePickerView:UIDatePicker = UIDatePicker()
            datePickerView.datePickerMode = UIDatePickerMode.date
           
            txtFieldDate.inputView = datePickerView
            
            datePickerView.addTarget(self, action: #selector(HDMakeReservationVC.datePickerValueChanged), for: UIControlEvents.valueChanged)
        }
        else if textField == txtFieldTime
        {
            let timePickerView:UIDatePicker = UIDatePicker()
            timePickerView.datePickerMode = UIDatePickerMode.time
            
            txtFieldTime.inputView = timePickerView
            
            timePickerView.addTarget(self, action: #selector(HDMakeReservationVC.TimePickerValueChanged), for: UIControlEvents.valueChanged)
        }
        else if textField == txtFieldAdults
        {
            self.AdultsPickerView.isHidden = false
            txtFieldAdults.inputView = AdultsPickerView
        }
        else if textField == txtFieldChildren
        {
            self.childrenPickerView.isHidden = false
            txtFieldChildren.inputView = childrenPickerView
        }
        else if textField == txtFieldMr
        {
            self.MrPickerView.isHidden = false
            txtFieldMr.inputView = MrPickerView
        }
        else
        {
            toolbar.update()
            activeInput = textField
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        toolbar.goForward()
        return true
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        toolbar.update()
        activeInput = textView
    }
    
       @objc func keyboardWillShow(_ notification: Notification) {
        let userInfo: NSDictionary = notification.userInfo! as NSDictionary
        let keyboardInfo = userInfo[UIKeyboardFrameBeginUserInfoKey] as! NSValue
        let keyboardSize = keyboardInfo.cgRectValue.size
        let contentInsets = UIEdgeInsets(top: 0, left: 0, bottom: keyboardSize.height + 90.0, right: 0)
        ScrollView.contentInset = contentInsets
        ScrollView.scrollIndicatorInsets = contentInsets
    }
    
    
    

    @objc func keyboardWillHide(_ notification: Notification) {
        ScrollView.contentInset = .zero
        ScrollView.scrollIndicatorInsets = .zero
    }
    
    deinit
    {
        NotificationCenter.default.removeObserver(self)
    }
    
    //MARK: - User Defined Methods
    func setLayout()
    {
        Constant().CENTERNAVTITLE(self.navigationItem, "MAKE RESERVATION")
        Constant().LEFTBACKBUTTON(navItem: self.navigationItem, ref: self)
        
       
        lblDate.font = Constant.FONT.medium.of(size: 13)
        lblNoOfDinner.font = Constant.FONT.medium.of(size: 13)
        lblTime.font = Constant.FONT.medium.of(size: 13)
        lblYourName.font = Constant.FONT.medium.of(size: 13)
        lblPhoneNo.font = Constant.FONT.medium.of(size: 13)
        lblSeparator.backgroundColor = Constant.COLOR.aColor_Grey
        lblNotes.font = Constant.FONT.medium.of(size: 13)
        lblCharacters.font = Constant.FONT.medium.of(size: 12)
        lblCharacters.textColor = Constant.COLOR.aColor_Grey
    }
    
    func btnPopTapped()
    {
        self.navigationController!.popViewController(animated: true)
    }
  
    func datePickerValueChanged(sender:UIDatePicker)
    {
        
        let dateFormatter = DateFormatter()
        
        dateFormatter.dateStyle = DateFormatter.Style.medium
        dateFormatter.timeStyle = DateFormatter.Style.none
        dateFormatter.dateFormat = "yyyy-MM-dd"
        txtFieldDate.text = dateFormatter.string(from: sender.date)
        txtFieldDate.resignFirstResponder()
        
    }
    
    func TimePickerValueChanged(sender: UIDatePicker) {
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        formatter.dateFormat = "hh:mm:ss"
        txtFieldTime.text = formatter.string(from: sender.date)
        txtFieldTime.resignFirstResponder()
    }
   
    @IBAction func btnBookNow(_ sender: Any)
    {
        //txtFieldDate, txtFieldAdults, txtFieldChildren, txtFieldTime , txtFieldMr , txtFieldFirstName, txtFieldLastName , txtFieldCountryCode , txtFieldPhoneNo , TextViewNote
        if((txtFieldDate.text?.isEmpty)! || (txtFieldAdults.text?.isEmpty)! || (txtFieldChildren.text?.isEmpty)! || (txtFieldTime.text?.isEmpty)! || (txtFieldMr.text?.isEmpty)! || (txtFieldFirstName.text?.isEmpty)! || (txtFieldLastName.text?.isEmpty)! || (txtFieldCountryCode.text?.isEmpty)! || (txtFieldPhoneNo.text?.isEmpty)!)
        {
            AlertBar.show(.info, message: "All Fields are required")
            return
        }
        do
        {
        let aDictParams : NSMutableDictionary = ["user_id":((UserDefaults.standard.value(forKey: "RegisteredUserProfile")!) as AnyObject).value(forKey: "user_id")!,"outlet_id":mutRestProfile.value(forKey: "outlet_id")!,"reservation_date":txtFieldDate.text! + txtFieldTime.text! , "adults":txtFieldAdults.text! , "child":txtFieldChildren.text! ,"user_first_name":txtFieldMr.text! + txtFieldFirstName.text!  , "user_last_name":txtFieldLastName.text! ,"user_country_code":txtFieldCountryCode.text!, "user_phone_number":txtFieldPhoneNo.text! ,"description" :TextViewNote.text!]
        DispatchQueue.global(qos:.default).async
        {
                HDWebServiceModal().callWebservice(aStrUrl: "reservation/create", aMutDictParams: aDictParams, ref: self, aStrTag: "MakeReservation")
        }
        }
    }
    func displayMyAlertMessage(userMessage:String)
    {
        let myAlert = UIAlertController(title:"alert" , message:userMessage ,preferredStyle:UIAlertControllerStyle.alert)
        
        let okAction = UIAlertAction(title:"ok" , style:UIAlertActionStyle.default , handler:nil)
        myAlert.addAction(okAction)
        self.present(myAlert,animated:true,completion:nil)
        
    }
    //MARK: -WebService Response
        
    func getWebserviceResponse(aDictResponse: NSDictionary, aStrTag: String)
    {
        // print("Response:::\(aDictResponse)")
        DispatchQueue.main.async
            {
                AppDelegate().getProgressInstance().hideProgressView()
        }
        
        if aStrTag == Constant.messages.KMsgNoInternet
        {
            AlertBar.show(.error, message: "No Internet Connection")
        }
        
        if aStrTag == "MakeReservation"
        {
            if ((aDictResponse.object(forKey: "result") as! NSDictionary).object(forKey: "status") as! NSString).isEqual(to: "success")
            {
            AlertBar.show(.info, message: (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "message") as! String)
            let aDictResponse : NSArray = (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "data") as! NSArray
                print(aDictResponse)
                
            }
            else
            {
                AlertBar.show(.error, message: (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "message") as! String)
                print("Response of Login Fail.")
            }
        }
            
    }

}
/*
 {
 result =     {
 data =         (
 );
 message = "Reservation created successfully.";
 status = success;
 };
 }
 */

