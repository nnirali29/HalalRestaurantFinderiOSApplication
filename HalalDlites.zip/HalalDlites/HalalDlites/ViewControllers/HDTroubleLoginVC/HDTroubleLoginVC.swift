//
//  HDTroubleLoginVC.swift
//  HalalDlites
//
//  Created by Yogesh on 10/02/17.
//  Copyright © 2017 CCS Group. All rights reserved.
//

import UIKit
import FormToolbar
class HDTroubleLoginVC: UIViewController,UITextFieldDelegate
{
    
  
    @IBOutlet weak var ScrollView: UIScrollView!
    @IBOutlet weak var lblTrouble: UILabel!
    @IBOutlet weak var lblEnterEmailPhone: UILabel!
    @IBOutlet weak var btnEmail: UIButton!
    @IBOutlet weak var btnPhone: UIButton!
    
    @IBOutlet weak var imgSeparator: UIImageView!
    @IBOutlet weak var imgIndicator: UIImageView!
    @IBOutlet weak var ViewEmailPhone: HDCommonBorderTextField!
    @IBOutlet weak var txtCode: UITextField!
    @IBOutlet weak var lblSeparator: UILabel!
    @IBOutlet weak var txtEmailPhone: UITextField!
    @IBOutlet weak var btnSenLink: HDCommonGreenButton!
    @IBOutlet weak var lblLine: UILabel!
    @IBOutlet weak var btnBackToLogin: UIButton!
   
    private lazy var toolbar: FormToolbar = {
        return FormToolbar(inputs: self.inputs)
    }()
    
    private var inputs: [FormInput] {
        return [txtCode, txtEmailPhone]
    }
    
    private weak var activeInput: FormInput?
    
    override func loadView() {
        super.loadView()
        
        //txtCode.delegate = self
        //txtEmailPhone.delegate = self
    }
    
    override func viewDidLayoutSubviews()
    {
        super.viewDidLayoutSubviews();
        
        DispatchQueue.main.async
        {
            self.ScrollView.contentSize = CGSize(width: self.view.frame.size.width , height:self.btnSenLink.frame.origin.y + self.btnSenLink.frame.size.height)
        }
        
    }
    

    override func viewDidLoad()
    {
        super.viewDidLoad()
        let dict = HDCommonMethodModel().methodToSetCountryCodeBasedOnCarier()
        print(dict)
        
        txtCode.text = "+" + String(dict.object(forKey: "country_code") as! Int)
        
        setLayout()
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: .UIKeyboardWillHide, object: nil)
       
       
        
    }
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
       
    }
    
    
    // MARK: - UITextFields Delegate Methods
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if textField == txtEmailPhone
        {
            if txtEmailPhone.placeholder == "Phone Number"
            {
                
                let currentCharacterCount = txtEmailPhone.text?.characters.count ?? 0
                if (range.length + range.location > currentCharacterCount)
                {
                    return false
                }
                let newLength = currentCharacterCount + string.characters.count - range.length
                return newLength <= 15
            }
            else if txtEmailPhone.placeholder == "Email Address"
            {
                let currentCharacterCount = txtEmailPhone.text?.characters.count ?? 0
                if (range.length + range.location > currentCharacterCount)
                {
                    return false
                }
                let newLength = currentCharacterCount + string.characters.count - range.length
                return newLength <= 50
            }
        }
            
        else if textField == txtCode
        {
            if (string == "" && txtCode.text == "+")
            {
                return false
            }
            if(range.location == 0)
            {
                return false
            }
            let currentCharacterCount = txtCode.text?.characters.count ?? 0
            if (range.length + range.location > currentCharacterCount)
            {
                return false
            }
            let newLength = currentCharacterCount + string.characters.count - range.length
            return newLength <= 4
        }
        
        return true
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        toolbar.update()
        activeInput = textField
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if (textField == txtEmailPhone)
        {
            self.view.endEditing(true)
            return false
        }
        else
        {
            toolbar.goForward()
            return true
        }
        
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        toolbar.update()
        activeInput = textView
    }

    func setLayout()
    {
        Constant().LEFTBACKBUTTON(navItem: self.navigationItem, ref: self)
        lblTrouble.textColor = Constant.COLOR.aColor_Green
        lblTrouble.font = Constant.FONT.medium.of(size: 18)
        lblEnterEmailPhone.textColor = Constant.COLOR.aColor_Grey
        lblEnterEmailPhone.font = Constant.FONT.medium.of(size: 13)
        btnPhone.setTitleColor(Constant.COLOR.aColor_Green, for: .normal)
        btnPhone.titleLabel?.font = Constant.FONT.medium.of(size: 18)
        btnEmail.setTitleColor(Constant.COLOR.aColor_Grey, for: .normal)
        btnEmail.titleLabel?.font = Constant.FONT.medium.of(size: 18)
        imgSeparator.backgroundColor = Constant.COLOR.aColor_Grey
        
        imgIndicator.backgroundColor = Constant.COLOR.aColor_Green
        txtCode.font=Constant.FONT.medium.of(size: 13)
        lblSeparator.backgroundColor = Constant.COLOR.aColor_Black
        txtEmailPhone.font = Constant.FONT.medium.of(size: 13)
        btnSenLink.titleLabel?.font = Constant.FONT.medium.of(size: 15)
        lblLine.backgroundColor = Constant.COLOR.aColor_Grey
        btnBackToLogin.titleLabel?.textColor = Constant.COLOR.aColor_Grey
        btnBackToLogin.titleLabel?.font = Constant.FONT.medium.of(size: 13)
        lblSeparator.backgroundColor = Constant.COLOR.aColor_Grey
    }
 
    func btnPopTapped()
    {
        self.navigationController!.popViewController(animated: true)
    }
    
    @IBAction func ButtonClicked(_ sender: Any)
    {
        let aBtnClicked = sender as! UIButton
        if aBtnClicked == btnBackToLogin
        {
            self.navigationController!.popViewController(animated: true)
        }
        else if aBtnClicked == btnPhone
        {
            self.toolbar = FormToolbar(inputs: [txtCode, txtEmailPhone])
            
            btnPhone.setTitleColor(Constant.COLOR.aColor_Green, for: .normal)
            btnEmail.setTitleColor(Constant.COLOR.aColor_Grey, for: .normal)
            
            imgIndicator.frame = CGRect(origin: CGPoint(x: imgSeparator.frame.origin.x,y :imgSeparator.frame.origin.y), size: CGSize(width: imgSeparator.frame.size.width/2, height: imgIndicator.frame.size.height))
            
            txtEmailPhone.frame = (frame : CGRect(x: ViewEmailPhone.frame.origin.x + lblSeparator.frame.origin.x ,
                                                  y: ViewEmailPhone.frame.origin.y,
                                                  width:  ViewEmailPhone.frame.size.width - 60,
                                                  height: txtEmailPhone.frame.size.height))
            
            txtEmailPhone.placeholder = "Phone Number"
            txtEmailPhone.text = ""
            txtCode.keyboardType = UIKeyboardType.phonePad
            txtEmailPhone.keyboardType = UIKeyboardType.phonePad
           
            txtCode.isHidden = false
            lblSeparator.isHidden = false
            
        }
        else if aBtnClicked == btnEmail
        {
            self.toolbar = FormToolbar(inputs: [txtEmailPhone])
            
            txtEmailPhone.resignFirstResponder()
            
            btnEmail.setTitleColor(Constant.COLOR.aColor_Green, for: .normal)
            btnPhone.setTitleColor(Constant.COLOR.aColor_Grey, for: .normal)
            
            txtEmailPhone.translatesAutoresizingMaskIntoConstraints = true
            
            txtEmailPhone.frame = (frame : CGRect(x:ViewEmailPhone.frame.origin.x + 10,
                                                  y:ViewEmailPhone.frame.origin.y,
                                                  width:  ViewEmailPhone.frame.size.width - 20,
                                                  height: txtEmailPhone.frame.size.height))

            
            imgIndicator.translatesAutoresizingMaskIntoConstraints = true
            
            imgIndicator.frame = CGRect(origin: CGPoint(x: imgSeparator.frame.origin.x + 128,y :imgSeparator.frame.origin.y), size: CGSize(width: imgSeparator.frame.size.width/2, height: imgIndicator.frame.size.height))
            
            
            txtEmailPhone.placeholder = "Email Address"
            txtEmailPhone.text = ""
            txtEmailPhone.keyboardType = UIKeyboardType.emailAddress
            
            txtCode.isHidden = true
            lblSeparator.isHidden = true
        }
        else if(aBtnClicked == btnSenLink)
        {
            if((txtCode.text?.isEmpty)! || (txtEmailPhone.text?.isEmpty)!)
            {
                AlertBar.show(.info, message: "All Fields are required")
                return
            }
            if txtEmailPhone.placeholder == "Email Address"
            {
                if HDCommonMethodModel().methodToValidateEmailAndWebsite(strEmailOrWebsite: txtEmailPhone.text!, type: "email")
                {
                let aDictParams : NSMutableDictionary = ["email_phone":txtEmailPhone.text!]
                DispatchQueue.global(qos:.default).async
                {
                    HDWebServiceModal().callWebservice(aStrUrl: "user/forgetpassword", aMutDictParams: aDictParams, ref: self, aStrTag: "ForgotPwd")
                }
                }
                else
                {
                    txtEmailPhone.text = ""
                    AlertBar.show(.info, message: "Email Id is not valid")
                    return
                }
            }
            else if txtEmailPhone.placeholder == "Phone Number"
            {
                let aDictParams : NSMutableDictionary = ["Country_code":txtCode.text! ,"email_phone":txtEmailPhone.text!]
                DispatchQueue.global(qos:.default).async
                {
                    HDWebServiceModal().callWebservice(aStrUrl: "user/forgetpassword", aMutDictParams: aDictParams, ref: self, aStrTag: "ForgotPwd")
                }
            }
            
        }

    }
    @objc func keyboardWillShow(_ notification: Notification) {
        let userInfo: NSDictionary = notification.userInfo! as NSDictionary
        let keyboardInfo = userInfo[UIKeyboardFrameBeginUserInfoKey] as! NSValue
        let keyboardSize = keyboardInfo.cgRectValue.size
        let contentInsets = UIEdgeInsets(top: 0, left: 0, bottom: keyboardSize.height + 90.0, right: 0)
        ScrollView.contentInset = contentInsets
        ScrollView.scrollIndicatorInsets = contentInsets
    }
    
    @objc func keyboardWillHide(_ notification: Notification) {
        ScrollView.contentInset = .zero
        ScrollView.scrollIndicatorInsets = .zero
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }

    
    
    //MARK: -WebService Response
    func getWebserviceResponse(aDictResponse: NSDictionary, aStrTag: String)
    {
        // print("Response:::\(aDictResponse)")
        DispatchQueue.main.async
        {
                AppDelegate().getProgressInstance().hideProgressView()
        }
        
        if aStrTag == Constant.messages.KMsgNoInternet
        {
             AlertBar.show(.error, message: "No Internet Connection")
        }
        
        if aStrTag == "ForgotPwd"
        {
            if ((aDictResponse.object(forKey: "result") as! NSDictionary).object(forKey: "status") as! NSString).isEqual(to: "success")
            {
                AlertBar.show(.info, message: ("Your new password is") + (((aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "data") as! NSDictionary).object(forKey: "password") as! String))
                let aDictResponse :NSDictionary = (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "data")as! NSDictionary
                
                print(aDictResponse)
                
                self.navigationController!.popViewController(animated: true)
            }
            else
            {
                AlertBar.show(.error, message: (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "message") as! String)

                print("Response of password change Fail.")
            }
        }
        
    }

}
