//
//  HDDrawerMenuCellVC.swift
//  HalalDlites
//
//  Created by user11 on 2/14/17.
//  Copyright © 2017 CCS Group. All rights reserved.
//

import UIKit

class HDDrawerMenuCellVC: UITableViewCell {

    @IBOutlet weak var imgArrow: UIImageView!
    @IBOutlet weak var imgMenuIcon: UIImageView!
    @IBOutlet weak var lblMenuItems: UILabel!
    @IBOutlet weak var lblLine: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        setLayout()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

     func setLayout()
     {
        lblLine.backgroundColor = Constant.COLOR.aColor_LightGrey
     }
}
