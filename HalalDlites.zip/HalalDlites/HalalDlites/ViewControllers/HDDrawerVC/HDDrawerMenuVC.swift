//
//  HDDrawerMenuVC.swift
//  HalalDlites
//
//  Created by Yogesh on 09/02/17.
//  Copyright © 2017 CCS Group. All rights reserved.
//

import UIKit

class HDDrawerMenuVC: UIViewController {

    
    
    @IBOutlet weak var lblTopLine: UILabel!
    
    @IBOutlet weak var DrawerMenuVC: UITableView!
   
    
    let cellID = "MenuOptionTableViewCell"
    let menuItems = [HDMenuOptions.home, HDMenuOptions.profile,HDMenuOptions.favourites,HDMenuOptions.bookmarks,HDMenuOptions.logout]
    
    let menuItemImg = ["home.png","uncheckProfile.png","uncheckFavourites.png","uncheckBookmark.png","logout.png"]
    var menuSelectionClosure: ((HDMenuOptions, Bool)-> Void)!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setLayout()
      
    }
    func setLayout()
    {
        lblTopLine.backgroundColor = Constant.COLOR.aColor_LightGrey
    }
}


//MARK: UITableViewDelegate

extension HDDrawerMenuVC:UITableViewDelegate
{
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return UITableViewAutomaticDimension
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        tableView.deselectRow(at: indexPath, animated: true)
        let menuItem = self.menuItems[indexPath.row]
        self.menuSelectionClosure(menuItem, true)
    }
    
}


//MARK: UITableViewDataSource

extension HDDrawerMenuVC:UITableViewDataSource
{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return menuItems.count
    }
    
    
    public func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 1.0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: cellID, for: indexPath) as! HDDrawerMenuCellVC
        let menuItem = self.menuItems[indexPath.row]
        cell.lblMenuItems.text = menuItem.rawValue
        cell.lblMenuItems.font = Constant.FONT.medium.of(size: 15)
        cell.lblMenuItems.textColor = Constant.COLOR.aColor_Black
        cell.imgMenuIcon.image = UIImage(named:self.menuItemImg[indexPath.row])
        cell.imgArrow.image = UIImage(named:"RightArrow.png")
        return cell
    }
    
}

public extension UITableViewCell
{
    func addSeparator(y: CGFloat, margin: CGFloat, color: UIColor)
    {
        let sepFrame = CGRect(x: margin, y: 0 , width:self.frame.width - margin, height:0.7);
        let seperatorView = UIView(frame: sepFrame);
        seperatorView.backgroundColor = color;
        self.addSubview(seperatorView);
    }
    
    public func addTopSeparator(tableView: UITableView)
    {
        let margin = tableView.separatorInset.left;
        
        self.addSeparator(y: 0, margin: margin, color: tableView.separatorColor!);
}
}
