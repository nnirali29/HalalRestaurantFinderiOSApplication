//
//  HDChangePwd.swift
//  HalalDlites
//
//  Created by user11 on 4/11/17.
//  Copyright © 2017 CCS Group. All rights reserved.
//

import UIKit

class HDChangePwd: UIViewController
{

    @IBOutlet weak var imgCurrentPwd: UIImageView!
    @IBOutlet weak var txtCurrentPwd: HDCommonBottomBorderTxtField!
    @IBOutlet weak var imgNewPwd: UIImageView!
    @IBOutlet weak var txtNewPwd: HDCommonBottomBorderTxtField!
    @IBOutlet weak var imgConfirmPwd: UIImageView!
    @IBOutlet weak var txtConfirmPwd: HDCommonBottomBorderTxtField!
    override func viewDidLoad()
    {
        super.viewDidLoad()
        setLayout()
        
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        
    }
    
    func setLayout()
    {
        Constant().CENTERNAVTITLE(self.navigationItem, "Password")
        Constant().RIGHTDONEBUTTON(navItem: self.navigationItem, ref: self)
        Constant().LEFTCANCELBUTTON(navItem: self.navigationItem, ref: self)
        imgCurrentPwd.image = UIImage(named:"lock.png")
        txtCurrentPwd.borderStyle = UITextBorderStyle.none
        imgNewPwd.image = UIImage(named:"lock.png")
        txtNewPwd.borderStyle = UITextBorderStyle.none
        imgConfirmPwd.image = UIImage(named:"lock.png")
        txtConfirmPwd.borderStyle = UITextBorderStyle.none
    }
    func btnDoneTapped()
    {
        if((txtCurrentPwd.text?.isEmpty)! || (txtNewPwd.text?.isEmpty)! || (txtConfirmPwd.text?.isEmpty)!)
        {
            AlertBar.show(.info, message: "All Fields are required")
            return
        }

        if((txtCurrentPwd.text)! != (UserDefaults.standard.value(forKey: "UserPassword")!) as! String)
        {
            AlertBar.show(.info, message: "Current Password Wrong.")
            self.txtCurrentPwd.text = ""
            return
        }
        if((txtCurrentPwd.text)! != (txtNewPwd.text!))
        {
            AlertBar.show(.info, message: "Enter new Password differ from current password.")
            self.txtNewPwd.text = ""
            return
        }
        if(txtNewPwd.text != txtConfirmPwd.text!)
        {
            //display error message
            AlertBar.show(.info, message: "Password does not match.")
            txtNewPwd.text = ""
            txtConfirmPwd.text = ""
            return
        }
        
        DispatchQueue.main.async
        {
                AppDelegate().getProgressInstance().showProgressView(self.view)
        }
        //{"user_id":3,"new_password":121212,"old_password":131313,"login_token":"8D3784435DA9E85589"}
        let aDictParams : NSMutableDictionary = ["user_id":(UserDefaults.standard.value(forKey: "RegisteredUserProfile") as AnyObject).value(forKey: "user_id")!,"new_password":txtNewPwd.text!,"old_password":txtCurrentPwd.text!,"login_token":(UserDefaults.standard.value(forKey: "RegisteredUserProfile") as AnyObject).value(forKey: "login_token")!]
        HDWebServiceModal().callWebservice(aStrUrl:"user/passwordchange", aMutDictParams:aDictParams, ref:self, aStrTag:"PasswordChange")
        
    }
    func btnCancelTapped()
    {
        self.navigationController!.popViewController(animated: true)
    }
    
  
    
    //MARK: -WebService Response
    func getWebserviceResponse(aDictResponse: NSDictionary, aStrTag: String)
    {
        // print("Response:::\(aDictResponse)")
        DispatchQueue.main.async
            {
                AppDelegate().getProgressInstance().hideProgressView()
        }
        if aStrTag == Constant.messages.KMsgNoInternet
        {
            AlertBar.show(.error, message: "No Internet Connection")
        }
        
        if aStrTag == "PasswordChange"
        {
            if ((aDictResponse.object(forKey: "result") as! NSDictionary).object(forKey: "status") as! NSString).isEqual(to: "success")
            {
                AlertBar.show(.info, message: (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "message") as! String)
                let aDictResponse :NSArray = (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "data")as! NSArray
                
                print(aDictResponse)
                
                
            }
            else
            {
                print("Password Does not change successfully.")
                AlertBar.show(.error, message: (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "message") as! String)

            }
        }
        
    }

}
