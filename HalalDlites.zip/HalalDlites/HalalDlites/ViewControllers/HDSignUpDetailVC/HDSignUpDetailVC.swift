//
//  HDSignUpDetailVC.swift
//  HalalDlites
//
//  Created by Yogesh on 06/02/17.
//  Copyright © 2017 CCS Group. All rights reserved.
//

import UIKit
import FormToolbar
import Photos
import MapKit

class HDSignUpDetailVC: UIViewController,UITextFieldDelegate,UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,CLLocationManagerDelegate
{

    var dictEmailPhoneFromVerification  : NSDictionary =  [:]
    @IBOutlet weak var ScrollView: UIScrollView!
    @IBOutlet weak var btnPhoto: UIButton!
   
    @IBOutlet weak var txtFieldFullName: HDCommonBorderTextField!
   
    @IBOutlet weak var txtFieldPwd: HDCommonBorderTextField!
    @IBOutlet weak var txtFieldConfirmedPwd: HDCommonBorderTextField!
    @IBOutlet weak var btnNext: HDCommonGreenButton!
   
    @IBOutlet weak var lblLine: UILabel!
    @IBOutlet weak var btnAl: UIButton!
    
    let imagePicker = UIImagePickerController()
    let locationManager = CLLocationManager()
    var userLatitude:CLLocationDegrees! = 0
    var userLongitude:CLLocationDegrees! = 0
    
    private lazy var toolbar: FormToolbar = {
        return FormToolbar(inputs: self.inputs)
    }()
    
    private var inputs: [FormInput] {
        return [txtFieldFullName,txtFieldPwd,txtFieldConfirmedPwd]
    }
    
    private weak var activeInput: FormInput?
    
    override func loadView()
    {
        super.loadView()
        txtFieldFullName.delegate = self
        txtFieldPwd.delegate = self
        txtFieldConfirmedPwd.delegate = self
        
    }
    override func viewDidLoad()
    {
        super.viewDidLoad()
        setLayout()
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: .UIKeyboardWillHide, object: nil)
        self.txtFieldConfirmedPwd.delegate = self
        
        
        self.locationManager.requestWhenInUseAuthorization()
        self.locationManager.startUpdatingLocation()
        
        if CLLocationManager.locationServicesEnabled()
        {
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
            locationManager.startMonitoringSignificantLocationChanges()
            
            userLatitude  = locationManager.location?.coordinate.latitude ?? 0
            userLongitude  = locationManager.location?.coordinate.longitude ?? 0
            
            print(userLatitude ?? "")
            print(userLongitude ?? "")
        }


    }
    override func viewDidLayoutSubviews()
    {
        super.viewDidLayoutSubviews();
         configureButton()
        DispatchQueue.main.async {
            self.ScrollView.contentSize = CGSize(width: self.view.frame.size.width , height:self.btnNext.frame.origin.y + self.btnNext.frame.size.height)
        }
    }
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
    }
    
    
    // MARK: - UITextFields Delegate Methods
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        toolbar.update()
        activeInput = textField
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if(textField == txtFieldConfirmedPwd)
        {
            self.view.endEditing(true)
            return false
        }
        else
        {
        toolbar.goForward()
        return true
        }
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        toolbar.update()
        activeInput = textView
        
    }
    // MARK: - User Defined Methods
    
    func setLayout()
    {
        Constant().CENTERNAVTITLE(self.navigationItem, "SIGN UP")
        Constant().LEFTBACKBUTTON(navItem: self.navigationItem, ref: self)
        
        txtFieldFullName.font = Constant.FONT.medium.of(size: 13)
        txtFieldPwd.font = Constant.FONT.medium.of(size: 13)
        txtFieldConfirmedPwd.font = Constant.FONT.medium.of(size: 13)
        btnNext.titleLabel?.tintColor=Constant.COLOR.aColor_Grey
        btnNext.titleLabel?.font=Constant.FONT.medium.of(size: 15)
        lblLine.backgroundColor=Constant.COLOR.aColor_Grey
        btnAl.titleLabel?.tintColor=Constant.COLOR.aColor_Grey
        btnAl.titleLabel?.font=Constant.FONT.medium.of(size: 12)
    }
    func configureButton()
    {
        //btnPhoto.setBackgroundImage(UIImage("AddPhoto.png", for: .normal)
       // btnPhoto.setImage(UIImage(named:"AddPhoto.png"), for: .normal)
        btnPhoto.layer.cornerRadius = 0.5 * btnPhoto.bounds.size.width
        btnPhoto.tintColor = Constant.COLOR.aColor_Green
        btnPhoto.clipsToBounds = true
    }
    
    // func thumbsUpButtonPressed() {
     //   print("thumbs up button pressed")
    //}
    
    func btnPopTapped()
    {
        self.navigationController!.popViewController(animated: true)
    }
    
    

    @IBAction func btnPhoto(_ sender: Any)
    {
        let alert = UIAlertController(title: nil, message: nil, preferredStyle: UIAlertControllerStyle.actionSheet)
        let CameraRoll = UIAlertAction(title: "Camera Roll", style:UIAlertActionStyle.default,handler:
            { (ACTION :UIAlertAction!)in
            if UIImagePickerController.isSourceTypeAvailable(.camera)
            {
                
                self.imagePicker.delegate = self
                self.imagePicker.allowsEditing = false
                self.imagePicker.sourceType = .camera
                self.imagePicker.mediaTypes = UIImagePickerController.availableMediaTypes(for: .camera)!
                self.present(self.imagePicker, animated: true, completion: nil)
            }
            else {
                self.noCameraAlert()
            }
        })
        let ChoosePhoto = UIAlertAction(title: "Choose Photo", style: UIAlertActionStyle.default,handler:
            { (ACTION :UIAlertAction!)in
                
                self.imagePicker.delegate = self
                self.imagePicker.allowsEditing = false
                self.imagePicker.sourceType = .photoLibrary
                
                self.navigationController?.present(self.imagePicker, animated: true, completion: nil)
                
        })
        
        let cancelButton = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel)
        
        alert.addAction(CameraRoll)
        alert.addAction(ChoosePhoto)
        alert.addAction(cancelButton)
        
        self.present(alert, animated: true, completion: nil)
        
    }
   
    func noCameraAlert() {
        let alertController = UIAlertController(title: "Error", message: "No camera available.", preferredStyle: .alert)
        let okayAction = UIAlertAction(title: "Okay", style: .default, handler: nil)
        alertController.addAction(okayAction)
        present(alertController, animated: true, completion: nil)
    }
    //MARK: -ImagePicker Delegate methods
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let chosenImage = info[UIImagePickerControllerOriginalImage] as! UIImage
       
        //btnPhoto.setImage(chosenImage, for: UIControlState.normal)
        btnPhoto.setBackgroundImage(chosenImage, for: .normal)
        dismiss(animated: true, completion: nil)
    }
    
   
    @IBAction func btnAl(_ sender: Any)
    {
        
         self.navigationController!.pushViewController(self.storyboard!.instantiateViewController(withIdentifier: "HDLoginVC") as UIViewController, animated: true)
      

    }
    
    
    @IBAction func btnNext(_ sender: Any)
    {
        //check for empty
        if((txtFieldFullName.text?.isEmpty)! || (txtFieldPwd.text?.isEmpty)! || (txtFieldConfirmedPwd.text?.isEmpty)!)
        {
            AlertBar.show(.info, message: "All Fields are required")
            return
        }
        if(txtFieldPwd.text)! != (txtFieldConfirmedPwd.text)!
        {
            AlertBar.show(.info, message: "Password does not match")
            
            return
        }
        if ( txtFieldPwd.text!.characters.count < 6 || txtFieldPwd.text!.characters.count > 20  )
        {
            AlertBar.show(.info, message: "password must be 6 to 20 characters long")
            txtFieldPwd.text = ""
            txtFieldConfirmedPwd.text = ""
            return
        }
        do
        {
            //call sms create api
            DispatchQueue.main.async
            {
                    AppDelegate().getProgressInstance().showProgressView(self.view)
            }
            
           if(dictEmailPhoneFromVerification.object(forKey: "isEmail") as! NSString).isEqual(to: "0")
           {
            var RemovePlus = "\(dictEmailPhoneFromVerification.object(forKey: "CountryCode")!)"
            RemovePlus.remove(at: RemovePlus.startIndex)
            
                let aDictParams : NSMutableDictionary = ["country_code":RemovePlus , "phone_number":dictEmailPhoneFromVerification.object(forKey: "PhoneNumber")!,"full_name":txtFieldFullName.text! , "password":txtFieldPwd.text!, "role":"2" , "device_type":"1" , "device_token":"DSFER4367FGD789789FSDF234" , "lat":String(userLatitude) , "lng":String(userLongitude) ,"verification_code":dictEmailPhoneFromVerification.object(forKey: "verification_code")!]

            
            let image : NSMutableDictionary = ["photo" : (btnPhoto.imageView?.image)! as UIImage , "key" : "photo"]
            let aArrImages : NSMutableArray = ([image])
            
            
                DispatchQueue.global(qos:.default).async
                {
                HDWebServiceModal().callMultipartWebservice(aStrUrl: "user/create", aMutDictParams: aDictParams, aMutArrImages: aArrImages, ref: self, aStrTag: "LOGINUsingPhone")
                }
            }
            else if(dictEmailPhoneFromVerification.object(forKey: "isEmail")as! NSString).isEqual(to: "1")
            {
                let aDictParams : NSMutableDictionary = ["email":dictEmailPhoneFromVerification.object(forKey: "Email")!,"full_name":txtFieldFullName.text! , "password":txtFieldPwd.text!, "role":"2" , "device_type":"1" , "device_token":"DSFER4367FGD789789FSDF234" , "lat":String(userLatitude) , "lng":String(userLongitude) ,"verification_code":dictEmailPhoneFromVerification.object(forKey: "verification_code")!]
                
                let image : NSMutableDictionary = ["photo" : (btnPhoto.imageView?.image)! as UIImage , "key" : "photo"]
                let aArrImages : NSMutableArray = ([image])
                
        
                DispatchQueue.global(qos:.default).async
                {
                HDWebServiceModal().callMultipartWebservice(aStrUrl: "user/create", aMutDictParams: aDictParams, aMutArrImages: aArrImages, ref: self, aStrTag: "LOGINUsingMail")
                }
            }
          
            
        }

    }
    
    @objc func keyboardWillShow(_ notification: Notification) {
        let userInfo: NSDictionary = notification.userInfo! as NSDictionary
        let keyboardInfo = userInfo[UIKeyboardFrameBeginUserInfoKey] as! NSValue
        let keyboardSize = keyboardInfo.cgRectValue.size
        let contentInsets = UIEdgeInsets(top: 0, left: 0, bottom: keyboardSize.height + 90.0, right: 0)
        ScrollView.contentInset = contentInsets
        ScrollView.scrollIndicatorInsets = contentInsets
    }
    
    @objc func keyboardWillHide(_ notification: Notification) {
        ScrollView.contentInset = .zero
        ScrollView.scrollIndicatorInsets = .zero
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    //MARK: -WebService Response
    
    func getWebserviceResponse(aDictResponse: NSDictionary, aStrTag: String)
    {
        // print("Response:::\(aDictResponse)")
        DispatchQueue.main.async
        {
                AppDelegate().getProgressInstance().hideProgressView()
        }
        
        if aStrTag == Constant.messages.KMsgNoInternet
        {
            AlertBar.show(.error, message: "No Internet Connection")
        }
        if aStrTag == "LOGINUsingPhone"
        {
            if ((aDictResponse.object(forKey: "result") as! NSDictionary).object(forKey: "status") as! NSString).isEqual(to: "success")
            {
                AlertBar.show(.info, message: (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "message") as! String)

                let aDictResponse : NSMutableDictionary = NSMutableDictionary(dictionary: (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "data") as! NSDictionary)

//                let aObj : HDSignUpVC = self.storyboard!.instantiateViewController(withIdentifier: "HDSignUpVC") as! HDSignUpVC
//                self.navigationController!.pushViewController(aObj, animated: true)
              
                UserDefaults.standard.set(aDictResponse , forKey :"RegisteredUserProfile")
                UserDefaults.standard.set(true, forKey: "isUserLoggedin")
                
                let appDelegate = UIApplication.shared.delegate as! AppDelegate
                appDelegate.window?.rootViewController = HDDrawerMenuOptionVC.sharedInstance.slidingPanel
                
            }
            else
            {
                print("error")
                AlertBar.show(.error, message: (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "message") as! String)

            }
        }

        else if aStrTag == "LOGINUsingMail"
        {
            if ((aDictResponse.object(forKey: "result") as! NSDictionary).object(forKey: "status") as! NSString).isEqual(to: "success")
            {
                AlertBar.show(.info, message: (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "message") as! String)
                let aDictResponse :NSDictionary = (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "data")as! NSDictionary

                UserDefaults.standard.set(aDictResponse , forKey :"RegisteredUserProfile")
                UserDefaults.standard.set(true, forKey: "isUserLoggedin")
                
                let appDelegate = UIApplication.shared.delegate as! AppDelegate
                appDelegate.window?.rootViewController = HDDrawerMenuOptionVC.sharedInstance.slidingPanel
            }
            else
            {
                print("error")
                AlertBar.show(.error, message: (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "message") as! String)

            }
         }
    }
}


