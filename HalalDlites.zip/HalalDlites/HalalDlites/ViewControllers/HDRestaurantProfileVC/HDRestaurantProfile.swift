//
//  HDRestaurantProfile.swift
//  HalalDlites
//
//  Created by user11 on 2/17/17.
//  Copyright © 2017 CCS Group. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class HDRestaurantProfile: UIViewController,FloatRatingViewDelegate,UIActionSheetDelegate,UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout
{
    var mutRestProfileFromLocation  : NSDictionary = [:]
    let UserDefaultresult = UserDefaults.standard.value(forKey: "RegisteredUserProfile")!
    @IBOutlet weak var ScrollView: UIScrollView!
    @IBOutlet weak var imgRestaurant: UIImageView!
    @IBOutlet weak var lblRestName: UILabel!
    @IBOutlet weak var lblRestDesc: UILabel!
   
    @IBOutlet weak var lblRestMenuSeparator: UILabel!
   
    @IBOutlet weak var lblRestMenu: UILabel!

    @IBOutlet weak var lblCollectionViewSeparator: UILabel!
  
    @IBOutlet weak var collectionViewRestImg: UICollectionView!
    
    @IBOutlet weak var lblViewAll: UILabel!
  
    @IBOutlet weak var lblLocationSeparator: UILabel!
   
    @IBOutlet weak var lblLocations: UILabel!
   
    @IBOutlet weak var lblMapViewSeparator: UILabel!
   
    @IBOutlet weak var mapRest: MKMapView!
  
    @IBOutlet weak var lblAddressSeparator: UILabel!
  
    @IBOutlet weak var lblAddress: UILabel!
    
    @IBOutlet weak var ViewUnderAddress: UIView!
    
    @IBOutlet weak var lblWebsiteSeparator: UILabel!
    @IBOutlet weak var lblWebsite: UILabel!
  
    @IBOutlet weak var lblWebAddressSeparator: UILabel!
    @IBOutlet weak var lblWebAddress: UILabel!
   
    
    /*
 {
 address1 = "Titanium square";
 address2 = thaltej;
 "c_date" = "2017-02-09 13:36:07";
 "c_user_id" = 15;
 city = Ahmedabad;
 "country_code" = 91;
 description = "best for veg";
 email = "2hmmainmunah@gmail.com";
 lat = "23.651";
 lng = "72.6369";
 name = "2 Hajah Maimunah Restaurant test";
 "outlet_id" = 1;
 "phone_number" = 8784559541;
 photo = "http://192.168.0.14/halal/uploads/images/1702/6ALmcViPPCecA8fESEphj1GusqHsJXPa.gif";
 photos =     (
 );
 "restaurant_id" = 1;
 state = Gujarat;
 status = 1;
 timezone = "";
 website =     (
 {
 website = "www.2hjamainmunah.com";
 },
 {
 website = "www.2devhjamimmunah.com";
 }
 );
 zip = 380061;
 }
*/
    
    
     
    override func viewDidLoad()
    {
        super.viewDidLoad()
            setLayout()
        print(UserDefaultresult)
        lblAddress.reloadInputViews()
        self.lblAddress.setNeedsDisplay()
        lblRestName.text = mutRestProfileFromLocation.value(forKey: "name") as! String?
        lblRestDesc.text = mutRestProfileFromLocation.value(forKey: "description") as! String?
        let picURL = ((self.mutRestProfileFromLocation).value(forKey: "photo") as! NSString)as String
        //let url = NSURL(string : picURL)
       // if let data = NSData(contentsOf : url! as URL)
        
        //{
        //imgRestaurant.image = UIImage(data : data as Data)
        //}
       LazyImage.show(imageView: imgRestaurant, url: picURL)
       
        
        let latDelta:CLLocationDegrees = 0.01
        
        let longDelta:CLLocationDegrees = 0.01
        
        let theSpan:MKCoordinateSpan = MKCoordinateSpanMake(latDelta, longDelta)
        let pointLocation:CLLocationCoordinate2D = CLLocationCoordinate2DMake((self.mutRestProfileFromLocation.value(forKey: "lat")! as! NSString).doubleValue,(self.mutRestProfileFromLocation.value(forKey: "lng")! as! NSString).doubleValue)
        
        let region:MKCoordinateRegion = MKCoordinateRegionMake(pointLocation, theSpan)
        mapRest.setRegion(region, animated: true)
        
        let pinLocation : CLLocationCoordinate2D = CLLocationCoordinate2DMake((self.mutRestProfileFromLocation.value(forKey: "lat")! as! NSString).doubleValue,(self.mutRestProfileFromLocation.value(forKey: "lng")! as! NSString).doubleValue)
        let objectAnnotation = MKPointAnnotation()
        objectAnnotation.coordinate = pinLocation
        objectAnnotation.title = (self.mutRestProfileFromLocation.value(forKey: "address1")! as! NSString) as String
        self.mapRest.addAnnotation(objectAnnotation)
        
        
        
               
       
        HDCommonMethodModel().StateCountryFromZip(zip: self.mutRestProfileFromLocation.value(forKey: "zip") as! String) { (state,country) in
        print(state)
        print(country)
        self.lblAddress.numberOfLines = 0
        self.lblAddress.translatesAutoresizingMaskIntoConstraints = true
        
       DispatchQueue.main.async {
        self.lblAddress.text! = "\(self.mutRestProfileFromLocation.value(forKey: "address1")!) , \(self.mutRestProfileFromLocation.value(forKey: "address2")!) \n\(self.mutRestProfileFromLocation.value(forKey: "city")!) , \(state) , \(country) - \(self.mutRestProfileFromLocation.value(forKey: "zip")!)"
        self.lblAddress.setNeedsDisplay()
       
        
        }
        }
        
       // lblAddress.text! = "\(mutRestProfileFromLocation.value(forKey: "address1")!) \n \(mutRestProfileFromLocation.value(forKey: "address2")!) , \(mutRestProfileFromLocation.value(forKey: "city")!)- \(mutRestProfileFromLocation.value(forKey: "zip")!)"
        
      
        let myArray = mutRestProfileFromLocation.value(forKey: "website") as! NSArray?
         print ("\(myArray!)" )
        
       let name = (myArray?.value(forKey: "website") as? NSArray)!
       print(name)
       lblWebAddress.numberOfLines = 0
       lblWebAddress.text = name.componentsJoined(by: "\n")
        
        
        
        /** Note: With the exception of contentMode, all of these
         properties can be set directly in Interface builder **/
        
        // Required float rating view params
//        self.rateView.emptyImage = UIImage(named: "uncheckRate")
//        self.rateView.fullImage = UIImage(named: "checkRate")
//        // Optional params
//        self.rateView.delegate = self
//        self.rateView.contentMode = UIViewContentMode.scaleAspectFit
//        // self.ratingView.maxRating = 5
//        // self.ratingView.minRating = 1
//        self.rateView.rating = 1
//        self.rateView.editable = false
//        self.rateView.halfRatings = true
//        self.rateView.floatRatings = true
        
        
    }
    
    override func viewDidLayoutSubviews()
    {
        DispatchQueue.main.async {
            self.ScrollView.contentSize = CGSize(width: self.view.frame.size.width , height:1000)
        }
        

    }

    
    func setLayout()
    {
        Constant().CENTERNAVTITLE(self.navigationItem, "RESTAURANT PROFILE")
        Constant().LEFTBACKBUTTON(navItem: self.navigationItem, ref: self)
        Constant().RIGHTMOREBUTTON(navItem: self.navigationItem, ref: self)
        
        lblRestName.textColor = Constant.COLOR.aColor_Green
        lblRestName.font = Constant.FONT.medium.of(size: 15)
        lblRestDesc.textColor = Constant.COLOR.aColor_Grey
        lblRestDesc.font = Constant.FONT.medium.of(size: 13)
        imgRestaurant.image = UIImage(named:"AddPhoto.png")
        lblRestMenuSeparator.backgroundColor = Constant.COLOR.aColor_LightGrey
        lblRestMenu.textColor = Constant.COLOR.aColor_Green
        lblCollectionViewSeparator.backgroundColor = Constant.COLOR.aColor_LightGrey
        lblViewAll.textColor = Constant.COLOR.aColor_Grey
        lblViewAll.font = Constant.FONT.medium.of(size: 11)
        lblLocationSeparator.backgroundColor = Constant.COLOR.aColor_LightGrey
        lblLocations.textColor = Constant.COLOR.aColor_Green
        lblLocations.font = Constant.FONT.medium.of(size: 15)
        lblMapViewSeparator.backgroundColor = Constant.COLOR.aColor_LightGrey
        lblAddressSeparator.backgroundColor = Constant.COLOR.aColor_LightGrey
        lblAddress.textColor = Constant.COLOR.aColor_Grey
        lblAddress.font = Constant.FONT.medium.of(size: 13)
        lblWebsiteSeparator.backgroundColor = Constant.COLOR.aColor_LightGrey
        lblWebsite.textColor = Constant.COLOR.aColor_Green
        lblWebsite.font = Constant.FONT.medium.of(size: 15)
        lblWebAddressSeparator.backgroundColor = Constant.COLOR.aColor_LightGrey
        lblWebAddress.textColor = Constant.COLOR.aColor_Grey
        lblWebAddress.font = Constant.FONT.medium.of(size: 13)
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
    }
    
    func btnPopTapped()
    {
        self.navigationController!.popViewController(animated: true)
    }
    
    func btnMoreTapped()
    {
        let alert = UIAlertController(title: nil, message: nil, preferredStyle: UIAlertControllerStyle.actionSheet)
        let BookmarkButton = UIAlertAction(title: "Add to Bookmark", style:UIAlertActionStyle.default,handler: { (ACTION :UIAlertAction!)in
            //{"outlet_id":"15","c_user_id":"25","login_token":"121212"}
            let aDictParams : NSMutableDictionary = ["outlet_id":self.mutRestProfileFromLocation.value(forKey: "outlet_id")!,"c_user_id":(self.UserDefaultresult as AnyObject).value(forKey: "user_id")!,"login_token":(self.UserDefaultresult as AnyObject).value(forKey: "login_token")! ]
    
            DispatchQueue.global(qos:.default).async
                {
                    HDWebServiceModal().callWebservice(aStrUrl: "bookmark/create", aMutDictParams: aDictParams, ref: self, aStrTag: "AddToBookmark")
            }
            
        })
        let MakeReservationButton = UIAlertAction(title: "Make Reservation", style:UIAlertActionStyle.default,handler: { (ACTION :UIAlertAction!)in
            
            let aObj : HDMakeReservationVC = self.storyboard!.instantiateViewController(withIdentifier: "HDMakeReservationVC") as! HDMakeReservationVC
            aObj.mutRestProfile = self.mutRestProfileFromLocation 
            self.navigationController!.pushViewController(aObj, animated: true)

        })
//        let OrderFoodButton = UIAlertAction(title: "Order Food", style: UIAlertActionStyle.default)
//        let CopyShareURLButton = UIAlertAction(title: "Copy Share URL", style: UIAlertActionStyle.default)
        
        let cancelButton = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel)
        alert.addAction(BookmarkButton)
        alert.addAction(MakeReservationButton)
     //   alert.addAction(OrderFoodButton)
    //alert.addAction(CopyShareURLButton)
        alert.addAction(cancelButton)
        self.present(alert, animated: true, completion: nil)
    }

    // MARK: FloatRatingViewDelegate
    
    func floatRatingView(_ ratingView: FloatRatingView, isUpdating rating:Float) {
        //self.liveLabel.text = NSString(format: "%.2f", self.floatRatingView.rating) as String
    }
    
    func floatRatingView(_ ratingView: FloatRatingView, didUpdate rating: Float) {
        //self.updatedLabel.text = NSString(format: "%.2f", self.floatRatingView.rating) as String
        
        print("hello")
        
    }



    // MARK: CollectionView DataSource methods
 
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return (mutRestProfileFromLocation.value(forKey: "photos") as! NSArray).count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
       let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "RestImage", for: indexPath) as! HDRestaurantProfileCell
        
        let photoes = ((mutRestProfileFromLocation.value(forKey: "photos") as! NSArray?)?.value(forKey: "photo") as? NSArray)!
        print(photoes)

        let picURL = photoes[indexPath.row] as! String
        
//        let url = NSURL(string : picURL)
//        if let data = NSData(contentsOf : url! as URL)
// 
//        {
//            cell.ImgRestImage.image = UIImage(data : data as Data)
//        }
         LazyImage.show(imageView: cell.ImgRestImage, url: picURL)
        return cell
    }
 
    // MARK: CollectionView Delegate methods
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let itemsPerRow:CGFloat = 3
        let hardCodedPadding:CGFloat = 1
        let itemWidth = (collectionView.bounds.width / itemsPerRow) - hardCodedPadding
        let itemHeight = collectionView.bounds.height - (2 * hardCodedPadding)
        return CGSize(width: itemWidth, height: itemHeight)
        
        
    }
    //MARK: -WebService Response
    
    func getWebserviceResponse(aDictResponse: NSDictionary, aStrTag: String)
    {
        // print("Response:::\(aDictResponse)")
               
        if aStrTag == Constant.messages.KMsgNoInternet
        {
            AlertBar.show(.error, message: "No Internet Connection")
        }
        
        if aStrTag == "AddToBookmark"
        {
            if ((aDictResponse.object(forKey: "result") as! NSDictionary).object(forKey: "status") as! NSString).isEqual(to: "Success")
            {
                AlertBar.show(.info, message: (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "message") as! String)
                
                let aDictResponse :NSArray = (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "data")as! NSArray
                
                print(aDictResponse)
                
            }
            else
            {
                AlertBar.show(.error, message: (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "message") as! String)
                print("Response of Add to Bookmark Fail.")
            }
        }
        
    }


}
