//
//  HDRestaurantProfileCell.swift
//  HalalDlites
//
//  Created by user11 on 3/30/17.
//  Copyright © 2017 CCS Group. All rights reserved.
//

import UIKit

class HDRestaurantProfileCell: UICollectionViewCell {
    
    @IBOutlet weak var ImgRestImage: UIImageView!
    override func awakeFromNib()
    {
        super.awakeFromNib()
     
    ImgRestImage.frame = bounds
    ImgRestImage.autoresizingMask = [.flexibleLeftMargin,
    .flexibleWidth,
    .flexibleRightMargin,
    .flexibleTopMargin,
    .flexibleHeight,
    .flexibleBottomMargin]
    
    }
}
