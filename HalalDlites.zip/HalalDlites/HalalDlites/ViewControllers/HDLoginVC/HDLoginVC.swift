//
//  HDLoginVC.swift
//  HalalDlites
//
//  Created by Yogesh on 30/01/17.
//  Copyright © 2017 CCS Group. All rights reserved.
//
import Foundation
import UIKit
import Alamofire
import MapKit
import CoreLocation

class HDLoginVC: UIViewController, UITextFieldDelegate,CLLocationManagerDelegate
{

    
    @IBOutlet weak var ViewCodePhone: HDCommonBorderTextField!
    @IBOutlet weak var txtCode: UITextField!
   
    @IBOutlet weak var txtEmailPhone: UITextField!
    @IBOutlet weak var txtPwd: HDCommonBorderTextField!
    @IBOutlet weak var btnFP: UIButton!
    @IBOutlet weak var btnLogin: HDCommonGreenButton!
    @IBOutlet weak var lblD: UILabel!
    @IBOutlet weak var btnSignUp: UIButton!
    
    var isphonenumber = false
    let locationManager = CLLocationManager()
    var userLatitude:CLLocationDegrees! = 0
    var userLongitude:CLLocationDegrees! = 0
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
       
        setLayout()
        
        txtCode.isHidden = true
        
        let dict = HDCommonMethodModel().methodToSetCountryCodeBasedOnCarier()
        print(dict)
        
        txtCode.text = "" + "+" + String(dict.object(forKey: "country_code") as! Int)
        self.txtPwd.delegate = self
        
      
        
       
        self.locationManager.requestWhenInUseAuthorization()
        self.locationManager.startUpdatingLocation()
    
        if CLLocationManager.locationServicesEnabled()
        {
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
            locationManager.startMonitoringSignificantLocationChanges()
            
            userLatitude  = locationManager.location?.coordinate.latitude ?? 0
            userLongitude  = locationManager.location?.coordinate.longitude ?? 0
            
            print(userLatitude ?? "")
            print(userLongitude ?? "")
        }

    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: - User Defined Methods
    
    func setLayout()
    {
        Constant().CENTERNAVTITLE(self.navigationItem, "LOGIN")
        //Constant().LEFTBACKBUTTON(navItem: self.navigationItem, ref: self)
        txtCode.textColor = Constant.COLOR.aColor_Black
        txtEmailPhone.font = Constant.FONT.medium.of(size: 13)
        txtPwd.font = Constant.FONT.medium.of(size: 13)
        btnFP.titleLabel?.font = Constant.FONT.medium.of(size: 12)
        btnLogin.titleLabel?.font = Constant.FONT.medium.of(size: 15)
        lblD.font = Constant.FONT.medium.of(size: 12)
        btnSignUp.titleLabel?.font=Constant.FONT.medium.of(size: 12)
    }

    @IBAction func btnForgotPwd(_ sender: Any)
    {
        
        self.navigationController!.pushViewController(self.storyboard!.instantiateViewController(withIdentifier: "HDTroubleLoginVC"), animated: true)
    }
    
    @IBAction func btnSignUp(_ sender: Any)
    {
        self.navigationController!.pushViewController(self.storyboard!.instantiateViewController(withIdentifier: "HDSignUpVC") as UIViewController, animated: true)
        
    }
    

    // MARK: - UITextFields Delegate Methods
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool
    {
        
        if textField == txtEmailPhone
        {
            var strFinalString = (txtEmailPhone.text)!.appending(string)
            let length = string.characters.count
            if (length == 0)
            {
                strFinalString = (strFinalString as NSString).substring(to: strFinalString.characters.count - 1)
            }
            do
            {
                let regex:NSRegularExpression = try NSRegularExpression( pattern:"[^0-9]" , options:[])
                // Assuming you have some NSString `myString`.
               // let matches = regex.matches(in: strFinalString, options: [], range: NSRange(location: 0, length: strFinalString.utf16.count))

                let matches  = regex.matches(in: strFinalString, options: [] , range: NSRange(location: 0, length: strFinalString.characters.count))
                
                
                if(matches.count > 0)
                {
                    isphonenumber = false
                    txtCode.isHidden = true
                    txtEmailPhone.placeholder = "Email"
                    txtEmailPhone.translatesAutoresizingMaskIntoConstraints = true
                    txtEmailPhone.frame = (frame :CGRect(x:17 ,y:txtEmailPhone.frame.origin.y ,width:txtPwd.frame.size.width - 17 , height:txtEmailPhone.frame.size.height ))

//                    if HDCommonMethodModel().methodToValidateEmailAndWebsite(strEmailOrWebsite: txtEmailPhone.text!, type: "email")
//                    {
//                        return true
//                    }
//                    else
//                    {
//                        txtEmailPhone.text = ""
//                        AlertBar.show(.info, message: "Email Id is not valid")
//                       
//                        return false
//                    }
//                
        
                    let currentCharacterCount = txtEmailPhone.text?.characters.count ?? 0
                    if (range.length + range.location > currentCharacterCount)
                    {
                        return false
                    }
                    
                    let newLength = currentCharacterCount + string.characters.count - range.length
                   
                    return newLength <= 50
                }
                else if(strFinalString == "")
                {
                    isphonenumber = false
                    txtCode.isHidden = true
                    txtEmailPhone.placeholder = "Email/Phone"
                    txtEmailPhone.translatesAutoresizingMaskIntoConstraints = true
                     txtEmailPhone.frame = (frame :CGRect(x:17 ,y:txtEmailPhone.frame.origin.y ,width:txtPwd.frame.size.width - 17 , height:txtEmailPhone.frame.size.height ))
                }
                else
                {
                    isphonenumber = true
                    txtCode.isHidden = false
                    txtEmailPhone.translatesAutoresizingMaskIntoConstraints = true
                    txtEmailPhone.frame = (frame :CGRect(x: txtCode.frame.size.width ,y:txtEmailPhone.frame.origin.y ,width:txtPwd.frame.size.width - txtCode.frame.size.width , height:txtEmailPhone.frame.size.height ))
                    txtEmailPhone.placeholder = "Phone Number"
                    
                    let currentCharacterCount = txtEmailPhone.text?.characters.count ?? 0
                   
                    if (range.length + range.location > currentCharacterCount)
                    {
                        return false
                    }
                    
                    let newLength = currentCharacterCount + string.characters.count - range.length
                    return newLength <= 15
                }
            }
            catch let error
            {
                print("invalid regex: \(error.localizedDescription)")
            }
        }
            
        
        else if textField == txtCode
        {
            if (string == "" && txtCode.text == "+")
            {
                return false
            }
            
            if(range.location == 0)
            {
                return false
            }
            
            let currentCharacterCount = txtCode.text?.characters.count ?? 0
            
            if (range.length + range.location > currentCharacterCount)
            {
                return false
            }
            
            let newLength = currentCharacterCount + string.characters.count - range.length
            return newLength <= 4
        }
        
        return true
    }

    

    @IBAction func btnLogin(_ sender: Any)
    {
        
        
        
        //check for empty
        if((txtEmailPhone.text?.isEmpty)! || (txtPwd.text?.isEmpty)!)
        {
            //display error message
            AlertBar.show(.info, message: "All Fields are required")
            return
        }
        do
        {
            //call sms create api
           
            if txtCode.isHidden == true
            {
                if HDCommonMethodModel().methodToValidateEmailAndWebsite(strEmailOrWebsite: txtEmailPhone.text!, type: "email")
                {
                DispatchQueue.main.async
                    {
                            AppDelegate().getProgressInstance().showProgressView(self.view)
                    }
                let aDictParams : NSMutableDictionary = ["email_phone":txtEmailPhone.text! , "password":txtPwd.text!, "login_with":"1" , "device_type":"1" , "device_token":"111" , "lat": String(userLatitude) , "lng": String(userLongitude)]
                
                UserDefaults.standard.set(txtPwd.text!, forKey :"UserPassword")
                
                DispatchQueue.global(qos:.default).async
                    {
                        HDWebServiceModal().callWebservice(aStrUrl: "user/login", aMutDictParams: aDictParams, ref: self, aStrTag: "USERLOGIN")
                    }
                
                }
                else
                {
                    txtEmailPhone.text = ""
                    AlertBar.show(.info, message: "Email Id is not valid")
                    return
                }
                
            }
            else if txtCode.isHidden == false
            {
                var RemovePlus = "\(txtCode.text!)"
                RemovePlus.remove(at: RemovePlus.startIndex)
                let aDictParams : NSMutableDictionary = ["country_code":RemovePlus,"email_phone":txtEmailPhone.text! , "password":txtPwd.text!, "login_with":"1" , "device_type":"1" , "device_token":"111" , "lat": String(userLatitude) , "lng": String(userLongitude)]
                
                UserDefaults.standard.set(txtPwd.text! , forKey :"UserPassword")
                
                DispatchQueue.global(qos:.default).async
                    {
                        HDWebServiceModal().callWebservice(aStrUrl: "user/login", aMutDictParams: aDictParams, ref: self, aStrTag: "USERLOGIN")
                    }
            }
        }

    }
    
    
    //MARK: -WebService Response
    
    func getWebserviceResponse(aDictResponse: NSDictionary, aStrTag: String)
    {
        // print("Response:::\(aDictResponse)")
        DispatchQueue.main.async
        {
            AppDelegate().getProgressInstance().hideProgressView()
        }
        
        if aStrTag == Constant.messages.KMsgNoInternet
        {
            AlertBar.show(.error, message: "No Internet Connection")
        }
        
        if aStrTag == "USERLOGIN"
        {
            if ((aDictResponse.object(forKey: "result") as! NSDictionary).object(forKey: "status") as! NSString).isEqual(to: "success")
            {
                AlertBar.show(.success, message: (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "message") as! String)
                
                let aDictResponse : NSMutableDictionary = NSMutableDictionary(dictionary: (aDictResponse.object(forKey: "result")as! NSDictionary).object as! NSDictionary)
                
                print(aDictResponse)
                
                let appDelegate = UIApplication.shared.delegate as! AppDelegate
                appDelegate.window?.rootViewController = HDDrawerMenuOptionVC.sharedInstance.slidingPanel
               
                UserDefaults.standard.set(aDictResponse , forKey :"RegisteredUserProfile")
                UserDefaults.standard.set(true, forKey: "isUserLoggedin")

            }
            else
            {
                AlertBar.show(.error, message: (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "message") as! String)

                print("Response of Login Fail.")
            }
        }
    }
}

/*
 aObj.dictVerFromSignUp = ["email_phone" : txtCode.text! + " " + txtPhone.text!, "sms_sent" : aDictResponse.value(forKey: "sms_sent")!, "verification_code" : aDictResponse.value(forKey: "verification_code")!]*/


