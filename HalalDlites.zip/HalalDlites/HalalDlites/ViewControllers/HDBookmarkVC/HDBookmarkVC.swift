//
//  HDBookmarkVC.swift
//  HalalDlites
//
//  Created by user11 on 4/6/17.
//  Copyright © 2017 CCS Group. All rights reserved.
//

import UIKit

class HDBookmarkVC: UIViewController,UITableViewDelegate,UITableViewDataSource
{

    var mutBookmarkRest: NSArray = []
    let result = UserDefaults.standard.value(forKey: "RegisteredUserProfile")!
   
    @IBOutlet weak var tblBookmarkRestList: UITableView!
        override func viewDidLoad() {
        super.viewDidLoad()
            setLayout()
            
            let aDictParams : NSMutableDictionary = ["login_token":(result as AnyObject).value(forKey: "login_token")! ,"c_user_id":(result as AnyObject).value(forKey: "user_id")!]
            
            DispatchQueue.global(qos:.default).async
            {
                    HDWebServiceModal().callWebservice(aStrUrl: "bookmark/list", aMutDictParams: aDictParams, ref: self, aStrTag: "BookmarkRestList")
            }


    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
   
        func setLayout()
    {
        
       // lblTopLine.backgroundColor = Constant.COLOR.aColor_LightGrey
        
        Constant().CENTERNAVTITLE(self.navigationItem, "Bookmark")
        Constant().LEFTDRAWERBUTTON(navItem: self.navigationItem, ref: self)
       // Constant().RIGHTSEARCHBUTTON(navItem: self.navigationItem, ref: self)
    }
    
  
    
    func btnDrawerTapped()
    {
        HDDrawerMenuOptionVC.sharedInstance.slidingPanel.toggleLeftSlidingPanel()
        
    }
    
    //MARK: - UITableView DataSource Methods
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
    
    public func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 1.0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
    return self.mutBookmarkRest.count
        
    }
    
//    (
//    {
//    "bookmark_id" = 11;
//    description = "best for veg";
//    name = "2 Hajah Maimunah Restaurant test";
//    "outlet_id" = 1;
//    photo = "http://192.168.0.14/halal/uploads/images/1702/6ALmcViPPCecA8fESEphj1GusqHsJXPa.gif";
//    }
//    )

    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell:HDBookmarkTableViewCell = tableView.dequeueReusableCell(withIdentifier: "CellBookmarkIdentifier") as! HDBookmarkTableViewCell
        
        
        // cell.ImgBookmarkRest.image = UIImage(named:self.mutBookmarkRest[indexPath.row] as! String)
        
        cell.lblBookmarkRestName.text = ((self.mutBookmarkRest.object(at: indexPath.row) as! NSDictionary).value(forKey: "name") as! NSString)as String
        
        cell.lblRestDescription.text = ((self.mutBookmarkRest.object(at: indexPath.row) as! NSDictionary).value(forKey: "description") as! NSString)as String
        
        let picURL = ((self.mutBookmarkRest.object(at: indexPath.row) as! NSDictionary).value(forKey: "photo") as! NSString)as String
//        let url = NSURL(string : picURL)
//        if let data = NSData(contentsOf : url! as URL)
//            
//        {
//            cell.ImgBookmarkRest.image = UIImage(data : data as Data)
//        }
         LazyImage.show(imageView: cell.ImgBookmarkRest, url: picURL)
        return cell
    }
    
    // MARK:  UITableViewDelegate Methods
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
//    {
//        tableView.deselectRow(at: indexPath as IndexPath, animated: true)
//        
//        
//        print(mutRestaurantProfile[indexPath.row])
//        let aObj : HDRestaurantProfile = self.storyboard!.instantiateViewController(withIdentifier: "HDRestaurantProfile") as! HDRestaurantProfile
//        aObj.mutRestProfileFromLocation = (mutRestaurantProfile[indexPath.row] as! NSDictionary)
//        self.navigationController!.pushViewController(aObj, animated: true)
//    }
    
    func getWebserviceResponse(aDictResponse: NSDictionary, aStrTag: String)
    {
        // print("Response:::\(aDictResponse)")
        DispatchQueue.main.async
        {
            AppDelegate().getProgressInstance().hideProgressView()
        }
        
        if aStrTag == Constant.messages.KMsgNoInternet
        {
            AlertBar.show(.error, message: "No Internet Connection")
        }
        
        if aStrTag == "BookmarkRestList"
        {
            if ((aDictResponse.object(forKey: "result") as! NSDictionary).object(forKey: "status") as! NSString).isEqual(to: "Success")
            {
                
                let aDictResponse :NSArray = (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "data") as! NSArray
                print(aDictResponse)
                
                mutBookmarkRest = aDictResponse
                //print(mutRestaurantProfile.value(forKey: "name") as! NSArray)
                tblBookmarkRestList.reloadData()
                
            }
        }
        else
        {
            AlertBar.show(.error, message: (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "message") as! String)
            print("Response of Bookmark List Fail.")
        }
    }
}


