//
//  HDBookmarkTableViewCell.swift
//  HalalDlites
//
//  Created by user11 on 4/7/17.
//  Copyright © 2017 CCS Group. All rights reserved.
//

import UIKit

class HDBookmarkTableViewCell: UITableViewCell {

    
    @IBOutlet weak var ImgBookmarkRest: UIImageView!
    @IBOutlet weak var lblBookmarkRestName: UILabel!
    @IBOutlet weak var lblRestDescription: UILabel!
    @IBOutlet weak var lblRowSeparater: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        setLayout()
    }

    override func setSelected(_ selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)

    }
    func setLayout()
    {
        lblBookmarkRestName.textColor = Constant.COLOR.aColor_Green
        lblBookmarkRestName.font = Constant.FONT.medium.of(size: 15)
        lblRestDescription.textColor = Constant.COLOR.aColor_Grey
        lblRestDescription.font = Constant.FONT.medium.of(size: 13)
        lblRowSeparater.backgroundColor = Constant.COLOR.aColor_LightGrey
        
    }
}
