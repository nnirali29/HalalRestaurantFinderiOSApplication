//
//  HDFavouriteVC.swift
//  HalalDlites
//
//  Created by user11 on 4/21/17.
//  Copyright © 2017 CCS Group. All rights reserved.
//

import UIKit

class HDFavouriteVC: UIViewController,UITableViewDataSource,UITableViewDelegate
{

    @IBOutlet weak var tblFavourite: UITableView!
    var mutFavouriteList : NSMutableArray = []
    var intFavouriteRow : Int!
    override func viewDidLoad()
    {
        super.viewDidLoad()
        setLayout()
        
        //{"c_user_id":30,"page_number":"1","login_token":"121212"}
        let aDictParams : NSMutableDictionary = ["login_token":(UserDefaults.standard.value(forKey: "RegisteredUserProfile") as AnyObject).value(forKey: "login_token")!,"c_user_id":(UserDefaults.standard.value(forKey: "RegisteredUserProfile") as AnyObject).value(forKey: "user_id")! ,"page_number":"1"]
        
        HDWebServiceModal().callWebservice(aStrUrl: "favourite/list", aMutDictParams: aDictParams, ref: self, aStrTag: "favouriteList")
        

    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        
    }
    func setLayout()
    {
        
        Constant().CENTERNAVTITLE(self.navigationItem, "FAVOURITES")
        
        //       if let controllerForHamburgur = HDDrawerMenuOptionVC.sharedInstance.slidingPanel.centerPanel as? UINavigationController {
        //            Constant().CENTERNAVTITLE((controllerForHamburgur.viewControllers.first?.navigationItem)!, "PROMOTIONS")
        //       }
        Constant().LEFTDRAWERBUTTON(navItem: self.navigationItem, ref: self)
     //   Constant().RIGHTSEARCHBUTTON(navItem: self.navigationItem, ref: self)
    }
   
    
    func btnDrawerTapped()
    {
        HDDrawerMenuOptionVC.sharedInstance.slidingPanel.toggleLeftSlidingPanel()
    }

    @IBAction func btnFavourite(_ sender: Any)
    {
        intFavouriteRow = (sender as AnyObject).tag
        
            let aDictParams : NSMutableDictionary = ["promotion_id":(mutFavouriteList.object(at: intFavouriteRow!) as AnyObject).value(forKey: "promotion_id")!,"c_user_id":(UserDefaults.standard.value(forKey: "RegisteredUserProfile") as AnyObject).value(forKey: "user_id")!,"login_token":(UserDefaults.standard.value(forKey: "RegisteredUserProfile") as AnyObject).value(forKey: "login_token")!]
            
            HDWebServiceModal().callWebservice(aStrUrl: "favourite/remove", aMutDictParams: aDictParams, ref: self, aStrTag: "UNFAVOURITE")
        

    }
    
    
    //MARK: UITableViewDataSource
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return mutFavouriteList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell:HDFavouriteTableViewCell = tableView.dequeueReusableCell(withIdentifier: "CellFavouriteIdentifier") as! HDFavouriteTableViewCell
        
        cell.lblPromotionTitle.text = ((self.mutFavouriteList.object(at: indexPath.row) as! NSDictionary).value(forKey: "title") as! NSString) as String
       
        let picURL = ((self.mutFavouriteList.object(at: indexPath.row) as! NSDictionary).value(forKey: "photo") as! NSString)as String
//        let url = NSURL(string : picURL)
//        
//        if let data = NSData(contentsOf : url! as URL)
//        {
//            cell.imgPromotionDish.image = UIImage(data : data as Data)
//        }
         LazyImage.show(imageView: cell.imgPromotionDish, url: picURL)
        cell.btnFavourite.tag = indexPath.row
        
        //cell.btnFavourite.addTarget(self, action: Selector(("btnFavouriteTapped")), for: .touchUpInside)
        
        cell.btnFavourite.tintColor = UIColor.red
        
        return cell
    }
    
    //MARK: UITableViewDelegate
    
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
//    {
//        tableView.deselectRow(at: indexPath as IndexPath, animated: true)
//        print(mutFavouriteList[indexPath.row])
//        
//    }
    
    
    
    //MARK: -WebService Response
    func getWebserviceResponse(aDictResponse: NSDictionary, aStrTag: String)
    {
        // print("Response:::\(aDictResponse)")
        DispatchQueue.main.async
            {
                AppDelegate().getProgressInstance().hideProgressView()
        }
        
        if aStrTag == Constant.messages.KMsgNoInternet
        {
            AlertBar.show(.error, message: "No Internet Connection")
        }
        
        if aStrTag == "favouriteList"
        {
            if ((aDictResponse.object(forKey: "result") as! NSDictionary).object(forKey: "status") as! NSString).isEqual(to: "success")
            {
                mutFavouriteList = NSMutableArray(array: (aDictResponse.object(forKey: "result") as! NSDictionary).object(forKey: "data") as! NSArray)
                
                tblFavourite.reloadData()
            }
            else
            {
                AlertBar.show(.error, message: (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "message") as! String)
                print("Response of promotion List Fail.")
            }
        }
        else if aStrTag == "UNFAVOURITE"
        {
            if ((aDictResponse.object(forKey: "result") as! NSDictionary).object(forKey: "status") as! NSString).isEqual(to: "success")
            {
                AlertBar.show(.info, message: (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "message") as! String)
                
                mutFavouriteList.removeObject(at: intFavouriteRow)
              
                
                tblFavourite.reloadData()
            }
            else
            {
                AlertBar.show(.error, message: (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "message") as! String)
                
                print("Response of Favourite Fail.")
            }
            
        }
    }
}
