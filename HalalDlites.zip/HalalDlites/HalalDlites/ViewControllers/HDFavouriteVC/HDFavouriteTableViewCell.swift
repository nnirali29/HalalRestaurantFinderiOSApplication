//
//  HDFavouriteTableViewCell.swift
//  HalalDlites
//
//  Created by user11 on 4/21/17.
//  Copyright © 2017 CCS Group. All rights reserved.
//

import UIKit

class HDFavouriteTableViewCell: UITableViewCell
{
    
    @IBOutlet weak var imgPromotionDish: UIImageView!
   
    @IBOutlet weak var lblPromotionTitle: UILabel!
    @IBOutlet weak var btnFavourite: UIButton!
   
    override func awakeFromNib()
    {
        super.awakeFromNib()
        setLayout()
    }

    override func setSelected(_ selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)

        
    }
    func setLayout()
    {
        
        btnFavourite.setImage(UIImage(named: "like.png"), for: UIControlState.normal)
        btnFavourite.tintColor = Constant.COLOR.aColor_Grey
        lblPromotionTitle.font = Constant.FONT.medium.of(size: 15)
        lblPromotionTitle.textColor = Constant.COLOR.aColor_Green
    }

}
