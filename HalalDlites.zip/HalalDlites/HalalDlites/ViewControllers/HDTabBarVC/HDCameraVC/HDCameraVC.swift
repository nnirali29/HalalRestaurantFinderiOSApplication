//
//  HDCameraVC.swift
//  HalalDlites
//
//  Created by user11 on 3/2/17.
//  Copyright © 2017 CCS Group. All rights reserved.
//

import UIKit


class HDCameraVC: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UITextViewDelegate
{

    @IBOutlet weak var btnAddPhoto: UIButton!
    @IBOutlet weak var ImgImagePicked: UIImageView!
    @IBOutlet weak var TextViewCaption: UITextView!
    override func viewDidLoad()
    {
        super.viewDidLoad()
        setLayout()
        self.TextViewCaption.delegate = self
       
    }
   

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
      
    }
    func setLayout()
    {
            Constant().CENTERNAVTITLE(self.navigationItem, "Camera Roll")
            Constant().LEFTBACKBUTTON(navItem: self.navigationItem, ref: self)
            Constant().RIGHTSHAREBUTTON(navItem: self.navigationItem, ref: self)
            TextViewCaption.text = "Write a caption here..."
            TextViewCaption.textColor = Constant.COLOR.aColor_LightGrey
    }
    // MARK:  UITextView Delegate Methods
    func textViewDidBeginEditing(_ textView: UITextView)
    {
        if  TextViewCaption.textColor == Constant.COLOR.aColor_LightGrey
        {
            TextViewCaption.text = nil
            TextViewCaption.textColor = Constant.COLOR.aColor_Black
        }
    }
    func textViewDidEndEditing(_ textView: UITextView)
    {
        if  TextViewCaption.text.isEmpty
        {
            TextViewCaption.text = "Write a caption here..."
            TextViewCaption.textColor = Constant.COLOR.aColor_LightGrey
        }
    }
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if(text == "\n") {
            TextViewCaption.resignFirstResponder()
            return false
        }
        return true
    }
    
    // MARK:  User Defined Methods
    @IBAction func btnAddPhoto(_ sender: Any)
    {
        let alert = UIAlertController(title: nil, message: nil, preferredStyle: UIAlertControllerStyle.actionSheet)
        let CameraButton = UIAlertAction(title: "Take Photo", style:UIAlertActionStyle.default,handler: { (ACTION :UIAlertAction!)in
            if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.camera)
            {
                let imagePicker = UIImagePickerController()
                imagePicker.delegate = self
                imagePicker.sourceType = UIImagePickerControllerSourceType.camera;
                imagePicker.allowsEditing = false
                self.present(imagePicker, animated: true, completion: nil)
            }
            else
            {
                self.noCameraAlert()
            }
        })
        let LibraryButton = UIAlertAction(title: "Choose Photo", style:UIAlertActionStyle.default,handler: { (ACTION :UIAlertAction!)in
            if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.photoLibrary) {
                let imagePicker = UIImagePickerController()
                imagePicker.delegate = self
                imagePicker.sourceType = UIImagePickerControllerSourceType.photoLibrary;
                imagePicker.allowsEditing = true
                self.present(imagePicker, animated: true, completion: nil)
            }
        })
        let cancelButton = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel)
        alert.addAction(CameraButton)
        alert.addAction(LibraryButton)
        alert.addAction(cancelButton)
        self.present(alert, animated: true, completion: nil)
    }
    
//    func imagePickerController(picker: UIImagePickerController, didFinishPickingImage image: UIImage!, editingInfo: [NSObject : AnyObject]!)
//    {
//        ImgImagePicked.image = image
//        
//        self.dismiss(animated: true, completion: nil);
//    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let chosenImage = info[UIImagePickerControllerOriginalImage] as! UIImage
        ImgImagePicked.image = chosenImage
        dismiss(animated: true, completion: nil)
    }
    

    func noCameraAlert()
    {
        let alertController = UIAlertController(title: "Error", message: "No camera available.", preferredStyle: .alert)
        let okayAction = UIAlertAction(title: "Okay", style: .default, handler: nil)
        alertController.addAction(okayAction)
        present(alertController, animated: true, completion: nil)
    }
    func btnPopTapped()
    {
        self.navigationController!.popViewController(animated: true)
    }
    
    func btnShareTapped()
    {
        let activityVC = UIActivityViewController(activityItems: [TextViewCaption.text!,ImgImagePicked.image!], applicationActivities: nil)
        activityVC.popoverPresentationController?.sourceView = self.view
        self.present(activityVC, animated: true, completion: nil)
        
    }
    
}
