//
//  HDLocationTableViewCell.swift
//  HalalDlites
//
//  Created by Yogesh on 08/02/17.
//  Copyright © 2017 CCS Group. All rights reserved.
//

import UIKit

class HDLocationTableViewCell: UITableViewCell,FloatRatingViewDelegate
{

    
  
    @IBOutlet weak var lblRowSeparator: UILabel!
   
    @IBOutlet weak var imgRestaurant: UIImageView!
    @IBOutlet weak var lblRestaurantName: UILabel!

    @IBOutlet weak var lblRestDescription: UILabel!
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
        setLayout()
        
        
//        // Required float rating view params
//        self.ratingView.emptyImage = UIImage(named: "uncheckRate")
//        self.ratingView.fullImage = UIImage(named: "checkRate")
//        // Optional params
//        self.ratingView.delegate = self
//        self.ratingView.contentMode = UIViewContentMode.scaleAspectFit
//       // self.ratingView.maxRating = 5
//       // self.ratingView.minRating = 1
//        self.ratingView.rating = 1
//        self.ratingView.editable = false
//        self.ratingView.halfRatings = true
//        self.ratingView.floatRatings = true
        
        
        // Labels init
     //   self.liveLabel.text = NSString(format: "%.2f", self.floatRatingView.rating) as String
      //  self.updatedLabel.text = NSString(format: "%.2f", self.floatRatingView.rating) as String
    }

    
    override func setSelected(_ selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)
    }
    
    //MARK: - User Defined Function
    func setLayout()
    {
        lblRowSeparator.backgroundColor = Constant.COLOR.aColor_LightGrey
        lblRestaurantName.textColor = Constant.COLOR.aColor_Green
        lblRestaurantName.font = Constant.FONT.medium.of(size: 15)
        lblRestDescription.textColor = Constant.COLOR.aColor_Grey
        lblRestDescription.font = Constant.FONT.medium.of(size: 13)
        
    }
    
 
    // MARK: FloatRatingViewDelegate
    
    func floatRatingView(_ ratingView: FloatRatingView, isUpdating rating:Float) {
        //self.liveLabel.text = NSString(format: "%.2f", self.floatRatingView.rating) as String
    }
    
    func floatRatingView(_ ratingView: FloatRatingView, didUpdate rating: Float) {
        //self.updatedLabel.text = NSString(format: "%.2f", self.floatRatingView.rating) as String
        
        print("hello")

    }

}
