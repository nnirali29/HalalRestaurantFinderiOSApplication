//
//  HDLoacationVC.swift
//  HalalDlites
//
//  Created by Yogesh on 08/02/17.
//  Copyright © 2017 CCS Group. All rights reserved.
//

import UIKit
import MapKit

class HDLoacationVC: UIViewController,UITableViewDataSource,UITableViewDelegate,CLLocationManagerDelegate
{
    @IBOutlet weak var lblTopLine: UILabel!
    @IBOutlet weak var TableViewRestaurantList: UITableView!
   

    let locationManager = CLLocationManager()
    var userLatitude:CLLocationDegrees! = 0
    var userLongitude:CLLocationDegrees! = 0

    var mutRestaurantProfile: NSArray = []
    override func viewDidLoad()
    {
        super.viewDidLoad()
        setLayout()
        self.locationManager.requestWhenInUseAuthorization()
        self.locationManager.startUpdatingLocation()
        
        if CLLocationManager.locationServicesEnabled()
        {
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
            locationManager.startMonitoringSignificantLocationChanges()
            
            userLatitude  = locationManager.location?.coordinate.latitude ?? 0
            userLongitude  = locationManager.location?.coordinate.longitude ?? 0
            
            print(userLatitude ?? "")
            print(userLongitude ?? "")
        }

        let aDictParams : NSMutableDictionary = ["lat":String(userLatitude) , "lng":String(userLongitude) , "country_code": 91, "page_number" : "1"]
        
        DispatchQueue.global(qos:.default).async
        {
                HDWebServiceModal().callWebservice(aStrUrl: "outlet/list", aMutDictParams: aDictParams, ref: self, aStrTag: "RestaurantList")
        }

    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
    }
    func setLayout()
    {
       
        lblTopLine.backgroundColor = Constant.COLOR.aColor_LightGrey
        
//        if let controllerForHamburgur = HDDrawerMenuOptionVC.sharedInstance.slidingPanel.centerPanel as? UINavigationController {
//            
//            Constant().RIGHTSEARCHBUTTON(navItem: (controllerForHamburgur.viewControllers.first?.navigationItem)!, ref:self)
//            Constant().LEFTDRAWERBUTTON(navItem: (controllerForHamburgur.viewControllers.first?.navigationItem)!, ref: self)
//            
//        }
        Constant().CENTERNAVTITLE(self.navigationItem, "Location")
        Constant().LEFTDRAWERBUTTON(navItem: self.navigationItem, ref: self)
       // Constant().RIGHTSEARCHBUTTON(navItem: self.navigationItem, ref: self)
    }
    
   
    
    func btnDrawerTapped()
    {
        HDDrawerMenuOptionVC.sharedInstance.slidingPanel.toggleLeftSlidingPanel()
        
    }
    
   //MARK: - UITableView DataSource Methods
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
    
    public func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 1.0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return self.mutRestaurantProfile.count
    }
  
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell:HDLocationTableViewCell = tableView.dequeueReusableCell(withIdentifier: "CellLocationIdentifier") as! HDLocationTableViewCell
       
        cell.lblRestaurantName.text = ((self.mutRestaurantProfile.object(at: indexPath.row) as! NSDictionary).value(forKey: "name") as! NSString)as String
        
        cell.lblRestDescription.text = ((self.mutRestaurantProfile.object(at: indexPath.row) as! NSDictionary).value(forKey: "description") as! NSString)as String
        
        let picURL = ((self.mutRestaurantProfile.object(at: indexPath.row) as! NSDictionary).value(forKey: "photo") as! NSString)as String
        //let url = NSURL(string : picURL)
        //if let data = NSData(contentsOf : url! as URL)
       
       // {
            //cell.imgRestaurant.image = UIImage(data : data as Data)
            
       // }
        LazyImage.show(imageView: cell.imgRestaurant, url: picURL)
       
        return cell
    }
    
    // MARK:  UITableViewDelegate Methods
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        tableView.deselectRow(at: indexPath as IndexPath, animated: true)
        
        
        print(mutRestaurantProfile[indexPath.row])
        let aObj : HDRestaurantProfile = self.storyboard!.instantiateViewController(withIdentifier: "HDRestaurantProfile") as! HDRestaurantProfile
        aObj.mutRestProfileFromLocation = (mutRestaurantProfile[indexPath.row] as! NSDictionary) 
        self.navigationController!.pushViewController(aObj, animated: true)
    }
    
    func getWebserviceResponse(aDictResponse: NSDictionary, aStrTag: String)
    {
        // print("Response:::\(aDictResponse)")
        DispatchQueue.main.async
            {
                AppDelegate().getProgressInstance().hideProgressView()
        }
        
        if aStrTag == Constant.messages.KMsgNoInternet
        {
            AlertBar.show(.error, message: "No Internet Connection")
        }
        
        if aStrTag == "RestaurantList"
            {
                if ((aDictResponse.object(forKey: "result") as! NSDictionary).object(forKey: "status") as! NSString).isEqual(to: "success")
                {
                    
                    let aDictResponse :NSArray = (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "data") as! NSArray
                    print(aDictResponse)
                    
                    mutRestaurantProfile = aDictResponse
                    //print(mutRestaurantProfile.value(forKey: "name") as! NSArray)
                    TableViewRestaurantList.reloadData()
                    
                }
            }
            else
            {
                print("Response of Login Fail.")
                AlertBar.show(.error, message: (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "message") as! String)
            }
        }
    }


