//
//  HDPromotionTableViewCell.swift
//  HalalDlites
//
//  Created by user11 on 3/3/17.
//  Copyright © 2017 CCS Group. All rights reserved.
//

import UIKit

class HDPromotionTableViewCell: UITableViewCell
{

    @IBOutlet weak var imgPromotionDish: UIImageView!
    @IBOutlet weak var ViewFavouriteShadow: UIView!
    @IBOutlet weak var imgFavourite: UIImageView!
    @IBOutlet weak var lblFavouriteCount: UILabel!
    @IBOutlet weak var lblPromotionTitle: UILabel!
    @IBOutlet weak var btnFavourite: UIButton!
   
    override func awakeFromNib()
    {
        super.awakeFromNib()
        setLayout()
        
        
    }
    override func setSelected(_ selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)
    }
    func setLayout()
    {
        ViewFavouriteShadow.backgroundColor = Constant.COLOR.aColor_Black
        ViewFavouriteShadow.layer.masksToBounds = false
        ViewFavouriteShadow.layer.shadowOpacity = 0.7
        
        imgFavourite.image = UIImage(named:"like.png")
        imgFavourite.image = imgFavourite.image!.withRenderingMode(.alwaysTemplate)
        imgFavourite.tintColor = UIColor.white
        lblFavouriteCount.textColor = UIColor.white
        btnFavourite.setImage(UIImage(named: "like.png"), for: UIControlState.normal)
        btnFavourite.tintColor = Constant.COLOR.aColor_Grey
        lblPromotionTitle.font = Constant.FONT.medium.of(size: 15)
        lblPromotionTitle.textColor = Constant.COLOR.aColor_Green
    }
    
   
    
}
