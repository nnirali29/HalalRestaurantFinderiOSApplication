//
//  HDPromotionVC.swift
//  HalalDlites
//
//  Created by user11 on 3/1/17.
//  Copyright © 2017 CCS Group. All rights reserved.
//

import UIKit

class HDPromotionVC: UIViewController,UITableViewDataSource,UITableViewDelegate
{

    @IBOutlet weak var PromotionTableView: UITableView!
    
    var mutPromotionList : NSMutableArray = []
    var intFavouriteRow : Int!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        setLayout()
       
        let aDictParams : NSMutableDictionary = ["country_code":"91","login_token":(UserDefaults.standard.value(forKey: "RegisteredUserProfile") as AnyObject).value(forKey: "login_token")!,"user_id":(UserDefaults.standard.value(forKey: "RegisteredUserProfile") as AnyObject).value(forKey: "user_id")!]
        
        HDWebServiceModal().callWebservice(aStrUrl: "promotion/list", aMutDictParams: aDictParams, ref: self, aStrTag: "PromotionList")
        
    }

    func setLayout()
    {
        
        Constant().CENTERNAVTITLE(self.navigationItem, "PROMOTIONS")
        
//       if let controllerForHamburgur = HDDrawerMenuOptionVC.sharedInstance.slidingPanel.centerPanel as? UINavigationController {
//            Constant().CENTERNAVTITLE((controllerForHamburgur.viewControllers.first?.navigationItem)!, "PROMOTIONS")
//       }
        Constant().LEFTDRAWERBUTTON(navItem: self.navigationItem, ref: self)
        //Constant().RIGHTSEARCHBUTTON(navItem: self.navigationItem, ref: self)
    }
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
      
    }
  

   
    func btnDrawerTapped()
    {
        HDDrawerMenuOptionVC.sharedInstance.slidingPanel.toggleLeftSlidingPanel()
    }
    
    @IBAction func btnFavourite(_ sender: Any)
    {
        intFavouriteRow = (sender as AnyObject).tag
        
        if (((mutPromotionList.object(at: intFavouriteRow!) as! NSDictionary).value(forKey: "favourite") as! NSString).isEqual(to: "0"))
        {
            let aDictParams : NSMutableDictionary = ["promotion_id":(mutPromotionList.object(at: intFavouriteRow!) as AnyObject).value(forKey: "promotion_id")!,"c_user_id":(UserDefaults.standard.value(forKey: "RegisteredUserProfile") as AnyObject).value(forKey: "user_id")!,"login_token":(UserDefaults.standard.value(forKey: "RegisteredUserProfile") as AnyObject).value(forKey: "login_token")!]
            
            HDWebServiceModal().callWebservice(aStrUrl: "favourite/create", aMutDictParams: aDictParams, ref: self, aStrTag: "FAVOURITE")
        }
        else
        {
            
            let aDictParams : NSMutableDictionary = ["promotion_id":(mutPromotionList.object(at: intFavouriteRow!) as AnyObject).value(forKey: "promotion_id")!,"c_user_id":(UserDefaults.standard.value(forKey: "RegisteredUserProfile") as AnyObject).value(forKey: "user_id")!,"login_token":(UserDefaults.standard.value(forKey: "RegisteredUserProfile") as AnyObject).value(forKey: "login_token")!]
            
            HDWebServiceModal().callWebservice(aStrUrl: "favourite/remove", aMutDictParams: aDictParams, ref: self, aStrTag: "UNFAVOURITE")
        }
        
        
    
    }
    
    //MARK: UITableViewDataSource
    
        func numberOfSections(in tableView: UITableView) -> Int
        {
            return 1
        }

        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
        {
            return mutPromotionList.count
        }
    
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
        {
            let cell:HDPromotionTableViewCell = tableView.dequeueReusableCell(withIdentifier: "CellPromotionIdentifier") as! HDPromotionTableViewCell
            
            cell.lblPromotionTitle.text = ((self.mutPromotionList.object(at: indexPath.row) as! NSDictionary).value(forKey: "title") as! NSString) as String
            cell.lblFavouriteCount.text = (mutPromotionList.object(at: indexPath.row) as! NSDictionary).value(forKey: "promotion_count") as! String?
            let picURL = ((self.mutPromotionList.object(at: indexPath.row) as! NSDictionary).value(forKey: "photo") as! NSString)as String
//            let url = NSURL(string : picURL)
//            
//            if let data = NSData(contentsOf : url! as URL)
//            {
//                cell.imgPromotionDish.image = UIImage(data : data as Data)
//            }
             LazyImage.show(imageView: cell.imgPromotionDish, url: picURL)
            cell.btnFavourite.tag = indexPath.row
           
            //cell.btnFavourite.addTarget(self, action: Selector(("btnFavouriteTapped")), for: .touchUpInside)
            
            
            if (((mutPromotionList.object(at: indexPath.row) as! NSDictionary).value(forKey: "favourite") as! NSString).isEqual(to: "1"))
            {
                cell.btnFavourite.tintColor = UIColor.red
            }
            else
            {
                cell.btnFavourite.tintColor = Constant.COLOR.aColor_Grey
            }
            
            return cell
        }
        
    //MARK: UITableViewDelegate
    
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
//    {
//        tableView.deselectRow(at: indexPath as IndexPath, animated: true)
//        print(mutPromotionList[indexPath.row])
//        
//    }
    
    

    //MARK: -WebService Response
    func getWebserviceResponse(aDictResponse: NSDictionary, aStrTag: String)
    {
        // print("Response:::\(aDictResponse)")
        DispatchQueue.main.async
            {
                AppDelegate().getProgressInstance().hideProgressView()
        }
        
        if aStrTag == Constant.messages.KMsgNoInternet
        {
            AlertBar.show(.error, message: "No Internet Connection")
        }
        
        if aStrTag == "PromotionList"
        {
            if ((aDictResponse.object(forKey: "result") as! NSDictionary).object(forKey: "status") as! NSString).isEqual(to: "success")
            {
                mutPromotionList = NSMutableArray(array: (aDictResponse.object(forKey: "result") as! NSDictionary).object(forKey: "data") as! NSArray)
                
                PromotionTableView.reloadData()
            }
            else
            {
                AlertBar.show(.error, message: (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "message") as! String)
                print("Response of promotion List Fail.")
            }
        }
        else if aStrTag == "FAVOURITE"
        {
            if ((aDictResponse.object(forKey: "result") as! NSDictionary).object(forKey: "status") as! NSString).isEqual(to: "success")
            {
                AlertBar.show(.info, message: (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "message") as! String)
                
                let aDictParams : NSMutableDictionary = ["favourite": "1", "photo": ((mutPromotionList.object(at: intFavouriteRow) as! NSDictionary).value(forKey: "photo") as! NSString) , "promotion_count":((mutPromotionList.object(at: intFavouriteRow) as! NSDictionary).value(forKey: "promotion_count") as! NSString)  , "promotion_id": ((mutPromotionList.object(at: intFavouriteRow) as! NSDictionary).value(forKey: "promotion_id") as! NSString) , "title": ((mutPromotionList.object(at: intFavouriteRow) as! NSDictionary).value(forKey: "title") as! NSString)]

                mutPromotionList.replaceObject(at: intFavouriteRow, with: aDictParams)
                
                PromotionTableView.reloadData()
            }
            else
            {
                AlertBar.show(.error, message: (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "message") as! String)
                
                print("Response of Favourite Fail.")
            }
        }
        else if aStrTag == "UNFAVOURITE"
        {
            if ((aDictResponse.object(forKey: "result") as! NSDictionary).object(forKey: "status") as! NSString).isEqual(to: "success")
            {
                AlertBar.show(.info, message: (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "message") as! String)
                
                let aDictParams : NSMutableDictionary = ["favourite": "0", "photo": ((mutPromotionList.object(at: intFavouriteRow) as! NSDictionary).value(forKey: "photo") as! NSString) , "promotion_count":((mutPromotionList.object(at: intFavouriteRow) as! NSDictionary).value(forKey: "promotion_count") as! NSString)  , "promotion_id": ((mutPromotionList.object(at: intFavouriteRow) as! NSDictionary).value(forKey: "promotion_id") as! NSString) , "title": ((mutPromotionList.object(at: intFavouriteRow) as! NSDictionary).value(forKey: "title") as! NSString)]
                
                mutPromotionList.replaceObject(at: intFavouriteRow, with: aDictParams)
                
                PromotionTableView.reloadData()
            }
            else
            {
                AlertBar.show(.error, message: (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "message") as! String)
                
                print("Response of Favourite Fail.")
            }

        }
    }
}
/*
 result =     {
 data =         (
 {
 favourite = 1;
 photo = "http://192.168.0.14/halal/uploads/images/1703/L6iynd44ILl_rc4DG5BBMKVov4vHpuFl.jpg";
 "promotion_count" = 2;
 "promotion_id" = 1;
 title = "Buy 2 only $15.90";
 },
 */





