//
//  HDDrawerCenterTabBarVC.swift
//  HalalDlites
//
//  Created by Yogesh on 10/02/17.
//  Copyright © 2017 CCS Group. All rights reserved.
//

import UIKit

class HDTabBarVC: UITabBarController
{
    override func viewDidLoad()
    {
        super.viewDidLoad()
        tabBarItems()
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
    }
    
    //MARK: - User Defined Methods
    func tabBarItems()
    {
        let tabbar = self.tabBar as UITabBar
        tabbar.backgroundColor = UIColor.white
        
        tabbar.layer.borderWidth = 0.50
        tabbar.layer.borderColor = Constant.COLOR.aColor_Grey.cgColor
        
        tabbar.items![0].image = UIImage(named:"uncheck_location.png")?.withRenderingMode(.alwaysOriginal)
        tabbar.items![1].image = UIImage(named:"uncheck_camera.png")?.withRenderingMode(.alwaysOriginal)
        tabbar.items![2].image = UIImage(named:"uncheck_promotion.png")?.withRenderingMode(.alwaysOriginal)
        
        (tabbar.items![0] ).selectedImage = UIImage(named: "location.png")?.withRenderingMode(.alwaysOriginal)
        (tabbar.items![1] ).selectedImage = UIImage(named: "camera.png")?.withRenderingMode(.alwaysOriginal)
        (tabbar.items![2] ).selectedImage = UIImage(named: "promotion.png")?.withRenderingMode(.alwaysOriginal)
    }
    func setLayout()
    {
    
    }
}
