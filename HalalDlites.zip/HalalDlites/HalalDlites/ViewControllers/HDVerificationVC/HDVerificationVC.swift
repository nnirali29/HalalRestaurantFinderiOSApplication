//
//  HDVerificationVC.swift
//  HalalDlites
//
//  Created by Yogesh on 06/02/17.
//  Copyright © 2017 CCS Group. All rights reserved.
//
import Foundation
import UIKit
import FormToolbar

class HDVerificationVC: UIViewController,UITextFieldDelegate
{
    var dictVerFromSignUp  : NSDictionary =  [:]
    var NewVerificationCode : NSDictionary = [:]
    
    @IBOutlet weak var ScrollView: UIScrollView!
   
    
    @IBOutlet weak var lblEnterVerification: UILabel!
 
    
    @IBOutlet weak var lblEmailPhone: UILabel!
    
    @IBOutlet weak var btnResendCode: UIButton!
    @IBOutlet weak var txtFieldConfirmedCode: HDCommonBorderTextField!
    @IBOutlet weak var btnNext: HDCommonGreenButton!
    @IBOutlet weak var lblLine: UILabel!
    @IBOutlet weak var btnBack: UIButton!
   
    
    
    private lazy var toolbar: FormToolbar = {
        return FormToolbar(inputs: self.inputs)
    }()
    
    private var inputs: [FormInput] {
        return [txtFieldConfirmedCode]
    }
    
    private weak var activeInput: FormInput?
    
    override func loadView()
    {
        super.loadView()
        txtFieldConfirmedCode.delegate = self
        
    }

    override func viewDidLoad()
    {
        super.viewDidLoad()
        setLayout()
        self.txtFieldConfirmedCode.delegate = self
        //print(dictVerFromSignUp)
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: .UIKeyboardWillHide, object: nil)
        
        if((dictVerFromSignUp.object(forKey: "sms_sent") as! NSString).isEqual(to: "0"))
        {
            txtFieldConfirmedCode.text = dictVerFromSignUp.object(forKey: "verification_code") as! String?
            let aEnterCode = "Enter the code that we sent to "

            
            if((dictVerFromSignUp.object(forKey: "isEmail") as! NSString).isEqual(to: "0"))
            {
                let code = dictVerFromSignUp.object(forKey: "CountryCode") as? String
                let phone = dictVerFromSignUp.object(forKey: "PhoneNumber") as? String
                
                lblEmailPhone.text = aEnterCode + code! + phone!
            }
            else if((dictVerFromSignUp.object(forKey: "isEmail") as! NSString).isEqual(to: "1"))
            {
                let aEmail = dictVerFromSignUp.object(forKey: "emailId") as? String
                lblEmailPhone.text = aEnterCode + aEmail!
            }
            
        }
    }
    
    override func viewDidLayoutSubviews()
    {
        super.viewDidLayoutSubviews();
 
        DispatchQueue.main.async {
            self.ScrollView.contentSize = CGSize(width: self.view.frame.size.width , height:self.btnNext.frame.origin.y + self.btnNext.frame.size.height)
        }
    }
 
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
    }
 
 
    func textFieldDidBeginEditing(_ textField: UITextField) {
        toolbar.update()
        activeInput = textField
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if(textField == txtFieldConfirmedCode)
        {
            self.view.endEditing(true)
            return false
        }
        else
        {
        toolbar.goForward()
        return true
        }
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        toolbar.update()
        activeInput = textView
    }

    // MARK: - User Defined Methods
    func setLayout()
    {
        Constant().CENTERNAVTITLE(self.navigationItem, "SIGN UP")
        Constant().LEFTBACKBUTTON(navItem: self.navigationItem, ref: self)
        lblEnterVerification.textColor = Constant.COLOR.aColor_Green
        lblEnterVerification.font = Constant.FONT.medium.of(size: 18)
        lblEmailPhone.textColor = Constant.COLOR.aColor_Grey
        lblEmailPhone.font = Constant.FONT.medium.of(size: 14)
        btnResendCode.setTitleColor(Constant.COLOR.aColor_Green, for: UIControlState.normal)
        btnResendCode.titleLabel?.font = Constant.FONT.medium.of(size: 14)
        txtFieldConfirmedCode.font = Constant.FONT.medium.of(size: 13)
        btnNext.titleLabel?.tintColor = Constant.COLOR.aColor_Grey
        btnNext.titleLabel?.font = Constant.FONT.medium.of(size: 15)
        lblLine.backgroundColor = Constant.COLOR.aColor_Grey
        btnBack.titleLabel?.tintColor = Constant.COLOR.aColor_Grey
        btnBack.titleLabel?.font = Constant.FONT.medium.of(size: 15)
    }
    
    func btnPopTapped()
    {
        self.navigationController!.popViewController(animated: true)
    }
    
   
    @IBAction func btnResendCode(_ sender: Any)
    {
        if((dictVerFromSignUp.object(forKey: "isEmail") as! NSString).isEqual(to: "0"))
        {
        let aDictParams : NSMutableDictionary = ["country_code":dictVerFromSignUp.object(forKey: "CountryCode")! , "phone_number":dictVerFromSignUp.object(forKey: "PhoneNumber")! , "used_for":"1"]
        HDWebServiceModal().callWebservice(aStrUrl: "sms/create", aMutDictParams: aDictParams, ref: self, aStrTag: "SMSCREATE")
        }
            
        else if ((dictVerFromSignUp.object(forKey: "isEmail") as! NSString).isEqual(to: "1"))

        {
        let aDictParams : NSMutableDictionary = ["email":dictVerFromSignUp.object(forKey: "emailId")!, "used_for":"1"]
        HDWebServiceModal().callWebservice(aStrUrl: "sms/create", aMutDictParams: aDictParams, ref: self, aStrTag: "SendEmail")
        }
    }
    @IBAction func btnNext(_ sender: Any)
    {
        
        DispatchQueue.main.async
        {
                AppDelegate().getProgressInstance().showProgressView(self.view)
        }
        if((dictVerFromSignUp.object(forKey: "verification_code") as! NSString).isEqual(to: txtFieldConfirmedCode.text!) || (NewVerificationCode.object(forKey: "verification_code") as! NSString).isEqual(to: txtFieldConfirmedCode.text!))
        {
            
            if((dictVerFromSignUp.object(forKey: "isEmail") as! NSString).isEqual(to: "0"))
            {
                let aObj : HDSignUpDetailVC = self.storyboard!.instantiateViewController(withIdentifier: "HDSignUpDetailVC") as! HDSignUpDetailVC
                aObj.dictEmailPhoneFromVerification = ["CountryCode" : dictVerFromSignUp.object(forKey: "CountryCode")!,"PhoneNumber":dictVerFromSignUp.object(forKey: "PhoneNumber")!, "isEmail": dictVerFromSignUp.object(forKey: "isEmail") ,"verification_code" : txtFieldConfirmedCode.text! , "UpdatedVerificationCode" : NewVerificationCode.object(forKey: "verification_code") as Any]
                
                self.navigationController!.pushViewController(aObj, animated: true)
                DispatchQueue.main.async
                {
                        AppDelegate().getProgressInstance().hideProgressView()
                }
            }
            
            else if ((dictVerFromSignUp.object(forKey: "isEmail") as! NSString).isEqual(to: "1"))
                
            {
                let aObj : HDSignUpDetailVC = self.storyboard!.instantiateViewController(withIdentifier: "HDSignUpDetailVC") as! HDSignUpDetailVC
                aObj.dictEmailPhoneFromVerification = ["Email":dictVerFromSignUp.object(forKey: "emailId")!, "isEmail": dictVerFromSignUp.object(forKey: "isEmail")! ,"verification_code" : txtFieldConfirmedCode.text! , "UpdatedVerificationCode" : NewVerificationCode.object(forKey: "verification_code")as Any]
                self.navigationController!.pushViewController(aObj, animated: true)
                DispatchQueue.main.async
                {
                        AppDelegate().getProgressInstance().hideProgressView()
                }
            }
        }
        else
        {
            AlertBar.show(.info, message: "Incorrect Verification Code!")
        }

    
    }
    
    @IBAction func btnBack(_ sender: Any)
    {
        self.navigationController!.popViewController(animated: true)
    }

    
    @objc func keyboardWillShow(_ notification: Notification) {
        let userInfo: NSDictionary = notification.userInfo! as NSDictionary
        let keyboardInfo = userInfo[UIKeyboardFrameBeginUserInfoKey] as! NSValue
        let keyboardSize = keyboardInfo.cgRectValue.size
        let contentInsets = UIEdgeInsets(top: 0, left: 0, bottom: keyboardSize.height + 90.0, right: 0)
        ScrollView.contentInset = contentInsets
        ScrollView.scrollIndicatorInsets = contentInsets
    }
    
    @objc func keyboardWillHide(_ notification: Notification) {
        ScrollView.contentInset = .zero
        ScrollView.scrollIndicatorInsets = .zero
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    func getWebserviceResponse(aDictResponse: NSDictionary, aStrTag: String)
    {
        
        if aStrTag == Constant.messages.KMsgNoInternet
        {
            AlertBar.show(.error, message: "No Internet Connection")
        }
        
        if aStrTag == "SMSCREATE"
        {
            if ((aDictResponse.object(forKey: "result") as! NSDictionary).object(forKey: "status") as! NSString).isEqual(to: "success")
            {
                
                let aDictResponse :NSDictionary = (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "data")as! NSDictionary

                NewVerificationCode = aDictResponse

                if (aDictResponse.object(forKey: "sms_sent") as! NSString).isEqual(to: "0")
                {
                    txtFieldConfirmedCode.text = (aDictResponse.object(forKey: "verification_code") as! String?)
                }
                else
                {
                    AlertBar.show(.info, message: "Please,Enter Verification Code")
                }
                
                
            }
            else
            {
                AlertBar.show(.error, message: (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "message") as! String)
            }
        }
        else if aStrTag == "SendEmail"
        {
            if ((aDictResponse.object(forKey: "result") as! NSDictionary).object(forKey: "status") as! NSString).isEqual(to: "success")
            {
                
                let aDictResponse :NSDictionary = (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "data")as! NSDictionary
                
                NewVerificationCode = aDictResponse
                
                if (aDictResponse.object(forKey: "sms_sent") as! NSString).isEqual(to: "0")
                {
                    txtFieldConfirmedCode.text = (aDictResponse.object(forKey: "verification_code") as! String?)
                    
                }
                else
                {
                    AlertBar.show(.info, message: "Please,Enter Verification Code")
                }
                
                
            }
            else
            {
                AlertBar.show(.error, message: (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "message") as! String)
            }

        }
    }
}


