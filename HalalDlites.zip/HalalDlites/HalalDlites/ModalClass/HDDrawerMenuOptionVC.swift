//
//  HDDrawerMenuOptionVC.swift
//  HalalDlites
//
//  Created by Yogesh on 09/02/17.
//  Copyright © 2017 CCS Group. All rights reserved.
//

import Foundation
import UIKit

enum HDMenuOptions : String {
    
    case home = "Home"
    case profile = "Profile"
    //case top_reviews = "Top Reviews"
    //case promotions = "Promotions"
    //case chefs_recommendation = "Chef's Recommendation"
    //case bloggers_recommendation = "Blogger's Recommendation"
    //case signature_dish = "Signature Dish"
    case favourites = "Favourites"
    case bookmarks = "Bookmarks"
    //case special_promotions = "Special Promotions"
    //case reward_points = "Reward Points"
    //case notifications = "Notifications"
    case logout = "Logout"
    
    var menuTitle: String {
        return String(describing: self)
    }
    
}


class HDDrawerMenuOptionVC: NSObject {
    
    static let sharedInstance = HDDrawerMenuOptionVC()
    
    let slidingPanel: HDDrawerPanelVC
    
    override init() {
        
        self.slidingPanel = HDDrawerPanelVC()
        
        super.init()
        
        let aStoryBoard = UIStoryboard(name: "Main", bundle: nil)
        let  aLeftDrawerMenuVC : HDDrawerMenuVC = aStoryBoard.instantiateViewController(withIdentifier: "HDDrawerMenuVC") as! HDDrawerMenuVC
        
        
        let aDetailVC : HDTabBarVC = aStoryBoard.instantiateViewController(withIdentifier: "HDTabBarVC") as! HDTabBarVC
        let aNavCtrl = UINavigationController(rootViewController:aDetailVC)
        
        self.slidingPanel.leftPanel = aLeftDrawerMenuVC
        self.slidingPanel.centerPanel = aNavCtrl
        
        aLeftDrawerMenuVC.menuSelectionClosure = {[weak self](selectedMenuOption: HDMenuOptions, animated:Bool) in
            self?.showScreenForMenuOption(menuOntion: selectedMenuOption, animation: animated)
        }
    }
    
    func showScreenForMenuOption(menuOntion: HDMenuOptions, animation animated: Bool)
    {
        
        if (menuOntion.menuTitle as NSString).isEqual(to: "bookmarks")
        {
            let detailController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HDBookmarkVC") as! HDBookmarkVC
            
            let navigation = UINavigationController(rootViewController:detailController)
            slidingPanel.centerPanel = navigation
            self.slidingPanel.showCenterPanel(animated: animated)
        }
        else if(menuOntion.menuTitle as NSString).isEqual(to: "profile")
        {
            let detailController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HDProfileVC") as! HDProfileVC
            
            let navigation = UINavigationController(rootViewController:detailController);
            slidingPanel.centerPanel = navigation
            self.slidingPanel.showCenterPanel(animated: animated)
        }
        else if(menuOntion.menuTitle as NSString).isEqual(to: "logout")
        {
//            let detailController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HDLoginVC") as! HDLoginVC
//            
//            let navigation = UINavigationController(rootViewController:detailController);
//            slidingPanel.centerPanel = navigation
//            self.slidingPanel.showCenterPanel(animated: animated)
            
            let aDictParams : NSMutableDictionary = ["user_id":(UserDefaults.standard.value(forKey: "RegisteredUserProfile") as AnyObject).value(forKey: "user_id")!  , "login_token":(UserDefaults.standard.value(forKey: "RegisteredUserProfile") as AnyObject).value(forKey: "login_token")!]
            
            DispatchQueue.global(qos:.default).async
                {
                    HDWebServiceModal().callWebservice(aStrUrl: "user/logout", aMutDictParams: aDictParams, ref: self, aStrTag: "LOGOUT")
                }
            self.slidingPanel.showCenterPanel(animated: animated)
        }
            
        else if(menuOntion.menuTitle as NSString).isEqual(to: "favourites")
        {
            let detailController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HDFavouriteVC") as! HDFavouriteVC
            
            let navigation = UINavigationController(rootViewController:detailController);
            slidingPanel.centerPanel = navigation
            self.slidingPanel.showCenterPanel(animated: animated)
        }
        else if(menuOntion.menuTitle as NSString).isEqual(to: "home")
        {
            slidingPanel.centerPanel = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HDTabBarVC") as! HDTabBarVC
            self.slidingPanel.showCenterPanel(animated: animated)
        }
        else
        {
            //let navigationController = self.slidingPanel.centerPanel as! UINavigationController
            //_ = navigationController.viewControllers.first as! HDTabBarVC
            //self.slidingPanel.showCenterPanel(animated: animated)
        }
        
    }
    //MARK: -WebService Response
    
    func getWebserviceResponse(aDictResponse: NSDictionary, aStrTag: String)
    {
        // print("Response:::\(aDictResponse)")
        DispatchQueue.main.async
            {
                AppDelegate().getProgressInstance().hideProgressView()
        }
        
        if aStrTag == Constant.messages.KMsgNoInternet
        {
            
        }
        
        if aStrTag == "LOGOUT"
        {
            if ((aDictResponse.object(forKey: "result") as! NSDictionary).object(forKey: "status") as! NSString).isEqual(to: "success")
            {
                
                let aDictResponse :NSArray = (aDictResponse.object(forKey: "result")as! NSDictionary).object(forKey: "data")as! NSArray
                
                print(aDictResponse)
                
                //defaults.set(nil, forKey: "RegisteredUserProfile")
                
                let defaults = UserDefaults.standard
                var keyValue = defaults.string(forKey:"RegisteredUserProfile")
                defaults.removeObject(forKey:"RegisteredUserProfile")
                //defaults.setValue("false", forKey: "isUserLoggedin")
                defaults.set(false, forKey: "isUserLoggedin")
                defaults.synchronize()
                
                
                let HDLoginVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HDLoginVC")
                let aNavCtrl = UINavigationController(rootViewController: HDLoginVC)
                let appDelegate = UIApplication.shared.delegate as! AppDelegate
                appDelegate.window?.rootViewController = aNavCtrl
                
            }
            else
            {
                print("Response of logout Fail.")
            }
        }
        
    }

}
