//
//  HDCommonMethodModel.swift
//  HalalDlites
//
//  Created by user11 on 3/14/17.
//  Copyright © 2017 CCS Group. All rights reserved.
//

import UIKit
import MessageUI
import CoreTelephony
import Foundation
import CoreLocation

class HDCommonMethodModel: NSObject
{
    func methodToGetCountryCodes() -> NSArray
    {
        var countryList = NSArray()
        
        let aStrFilePath = Bundle.main.path(forResource: "PhoneCountries", ofType: "txt")
        let aDataOfPath = NSData(contentsOfFile: aStrFilePath!)
        
        var aStrData : NSString = NSString()
        
        if aDataOfPath != nil{
            aStrData = NSString(data: aDataOfPath! as Data, encoding: String.Encoding.utf8.rawValue)!
        }
        
        if aDataOfPath == nil{
            return countryList
        }
        
        let delimeter = ";"
        let endOfLine = "\n"
        
        let mutArrList = NSMutableArray()
        var currentLocation = 0
        
        while true
        {
            let codeRange = (aStrData.range(of: delimeter, options: NSString.CompareOptions(rawValue: 0), range: NSMakeRange(currentLocation, ((aStrData.length) - currentLocation))))
            
            if codeRange.location == NSNotFound{
                break
            }
            
            let countryCode = Int((aStrData.substring(with: NSMakeRange(currentLocation, codeRange.location - currentLocation))))
            
            let idRange = (aStrData.range(of: delimeter, options: NSString.CompareOptions(rawValue: 0), range: NSMakeRange(codeRange.location + 1 , aStrData.length - (codeRange.location + 1))))
            
            if idRange.location == NSNotFound{
                break
            }
            
            let countryId = (aStrData.substring(with: NSMakeRange(codeRange.location + 1 , idRange.location - (codeRange.location + 1)))).uppercased()
            
            
            let nameRange = aStrData.range(of:endOfLine , options: NSString.CompareOptions(rawValue: 0), range: NSMakeRange(idRange.location + 1, aStrData.length - (idRange.location + 1)))
            
            if nameRange.location == NSNotFound
            {
                break
            }
            
            var countryname = aStrData.substring(with: NSMakeRange(idRange.location + 1, nameRange.location - (idRange.location + 1))) as NSString
            
            if countryname.hasSuffix("\r")
            {
                countryname = countryname.substring(to: countryname.length) as NSString
            }
            
            let arrOfObject : Array = [NSNumber(value: countryCode!), countryId, countryname] as [Any]
            
            
            mutArrList.add(arrOfObject)
            
            currentLocation = Int(nameRange.location) + Int(nameRange.length);
            if nameRange.length > 1
            {
                break;
            }
        }
        
        countryList = mutArrList
        
        return countryList
    }
    
    //MARK: AlertView Method
    func alert(title:NSString,message:NSString,viewcontroller:AnyObject)
    {
        let alert = UIAlertController(title: title as String, message: message as String, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
        viewcontroller.present(alert, animated: true, completion: nil)
    }
    
    //MARK: Validate Email and Website
    func methodToValidateEmailAndWebsite(strEmailOrWebsite:String,type:String) -> Bool
    {
        var aStrEmailRegex = String()
        
        if type.isEqual("email")
        {
            aStrEmailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
        }
        else if type.isEqual("website")
        {
            aStrEmailRegex = "(?:(?:http|https)://)?[a-zA-Z0-9./?:@\\-_=#]+\\.([a-zA-Z0-9./?:@\\-_=#])*"
        }
        
        let predicateTest = NSPredicate(format: "SELF MATCHES %@", aStrEmailRegex)
        return predicateTest.evaluate(with: strEmailOrWebsite)
    }
    
    //MARK: Get Country Code Based On Location
    
    func countryName(byCountryId countryId: String, code: Int) -> NSDictionary
    {
        var aDicData = NSDictionary()
        
        let normalizedCountryId: String = countryId.uppercased()
        let arrCountryData = methodToGetCountryCodes()
        
        for index in 0..<arrCountryData.count
        {
            let aArray : NSArray = arrCountryData.object(at: index) as! NSArray
            let itemCountryId = aArray.object(at: 1) as! NSString
            
            if (itemCountryId as String == normalizedCountryId) {
                let countryCode = aArray[0] as! Int
                
                
                aDicData = ["country_name":aArray.object(at: 2),"country_code":countryCode]
                
                return aDicData
            }
        }
        return aDicData
    }
    
    func methodToSetCountryCodeBasedOnCarier() -> NSDictionary
    {
        var countryId : NSString? = nil
        
        let networkInfo = CTTelephonyNetworkInfo()
        
        let carrier = networkInfo.subscriberCellularProvider
        if carrier != nil
        {
            let mcc = carrier?.isoCountryCode
            
            if mcc != nil {
                countryId = mcc as NSString?
            }
        }
        
        if countryId == nil {
            if let countryCode = (Locale.current as NSLocale).object(forKey: .countryCode) as? String
            {
                countryId = countryCode as NSString
            }
        }
        
        let code = 0
        let aDicCountryData = self.countryName(byCountryId: countryId as! String, code: code)
        
        if aDicCountryData.object(forKey: "country_code") as! Int == 0{
            aDicCountryData.setValue(0, forKey: "country_code")
        }
        
        return aDicCountryData as NSDictionary
    }
    
    
    //MARK: Get Country Code Based On zip
    func StateCountryFromZip (zip : String , completion: @escaping (_ state: String , _ country :String)->())
    {
        CLGeocoder().geocodeAddressString(zip, completionHandler: {(placemarks: [CLPlacemark]?, error: Error?) -> Void in
            if ((placemarks?.count)! > 0)
            {
                let placemark: CLPlacemark = (placemarks?[0])!
                let country : String = placemark.country!
                let state: String = placemark.administrativeArea!
                print(state)
                print(country)
                completion(state , country)
            }
            
        } )
    }

    //MARK: Convert Json String
    
    func convertJsonStringToArray(strJson:String) -> Array<Any>
    {
        let dataFromString = strJson.data(using: .utf8)!
        
        do {
            return try JSONSerialization.jsonObject(with: dataFromString) as! [Any]
        } catch {
            print("json error: \(error.localizedDescription)")
        }
        
        return []
    }
    
    func convertJsonStringToDictionary(strJson:String) -> Dictionary<String, Any>
    {
        let dataFromString = strJson.data(using: .utf8)!
        
        do {
            return try JSONSerialization.jsonObject(with: dataFromString) as! [String:Any]
        } catch {
            print("json error: \(error.localizedDescription)")
        }
        
        return [:]
    }
    
    func convertObjectToJsonString(object:AnyObject) -> String {
        
        if let json = try? JSONSerialization.data(withJSONObject: object, options: [])
        {
            if let strJson = String(data: json, encoding: String.Encoding.utf8)
            {
                return strJson
            }
        }
        return ""
    }
    
    //MARK: -Height From String
    
    func methodToGetHeightFromString(text:String, fontSize:CGFloat, contentWidth:CGFloat) -> CGFloat
    {
        let yourAttributes = [NSForegroundColorAttributeName: UIColor.black, NSFontAttributeName: UIFont.systemFont(ofSize: fontSize)]
        
        let aSize = CGSize(width: contentWidth, height:Constant.structDeviceScreen.kScreenHeight)
        
        let r = text.boundingRect(with: aSize, options: NSStringDrawingOptions.usesLineFragmentOrigin,attributes: yourAttributes, context:nil)
        
        return r.size.height
        
    }
}

