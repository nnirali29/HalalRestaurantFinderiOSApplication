//
//  HDWebServiceModal.swift
//  HalalDlites
//
//  Created by user11 on 3/7/17.
//  Copyright © 2017 CCS Group. All rights reserved.
//


import UIKit
import Alamofire

class HDWebServiceModal: NSObject
{
    func checkNetworkStatus() -> Bool {
        
        _ = Reachability.init(hostname: "www.google.com")
        var isAvailabel = Bool()
        
        let hostStatus = Reachability.forInternetConnection().currentReachabilityStatus()
        
        switch hostStatus {
        case NotReachable:
            isAvailabel = false
            break
        case ReachableViaWiFi:
            isAvailabel = true
            break
        case ReachableViaWWAN:
            isAvailabel = true
            break
        default: break
        }
        
        return isAvailabel
    }
    
    func callWebservice (aStrUrl:String, aMutDictParams:NSMutableDictionary, ref:AnyObject, aStrTag:String)
    {
        if !checkNetworkStatus() {
            
            DispatchQueue.global(qos: .default).async{
                
                DispatchQueue.main.async {
                    
                    print("No Internet")
                    
                    AlertBar.show(.error, message: "No Internet Connection", duration: Constant.messages.kMsgDuration, completion: nil)
                    ref.getWebserviceResponse(aDictResponse: NSMutableDictionary.init(), aStrTag: Constant.messages.KMsgNoInternet)
                }
            }
            return
        }
        
        let aStrFinalUrl = "\(Constant.structCommanUrl.kCommanUrl)\(aStrUrl)"
        
        print(aMutDictParams)
        var request = URLRequest(url: URL(string: aStrFinalUrl)!)
        request.httpMethod = "POST"
        request.httpBody = try! JSONSerialization.data(withJSONObject: aMutDictParams)
        
        let aJsonStr = try! JSONSerialization.data(withJSONObject: aMutDictParams)
        print("\(String(data: aJsonStr,encoding: .ascii)!)")
        Alamofire.request(request).responseJSON { response in
            
            switch response.result{
                
            case .success:
                
                let aDictResponse = try! JSONSerialization.jsonObject(with: response.data!) as! NSDictionary
                
                ref.getWebserviceResponse(aDictResponse: aDictResponse, aStrTag: aStrTag)
                
                print(aDictResponse)
                
            case .failure(let error):
                print(error)
            }
            
        }
        
    }
    
    func callMultipartWebservice(aStrUrl:String, aMutDictParams:NSMutableDictionary, aMutArrImages: NSMutableArray, ref:AnyObject, aStrTag:String)
    {
        if !checkNetworkStatus() {
            
            DispatchQueue.global(qos: .default).async{
                
                DispatchQueue.main.async {
                    
                    print("No Internet")
                    
                    AlertBar.show(.error, message: "No Internet Connection", duration: Constant.messages.kMsgDuration, completion: nil)
                    ref.getWebserviceResponse(aDictResponse: NSMutableDictionary.init(), aStrTag: "No Internet")
                }
            }
            return
        }
        
        let aStrFinalUrl = "\(Constant.structCommanUrl.kCommanUrl)\(aStrUrl)"
        
        Alamofire.upload(
            multipartFormData: { (multipartFormData) in
                
                let aJsonStr = try! JSONSerialization.data(withJSONObject: aMutDictParams)
                
                print("\(String(data: aJsonStr,encoding: .ascii)!)")
                
                multipartFormData.append(try! JSONSerialization.data(withJSONObject: aMutDictParams), withName: "post_data")
                
                for aInt in 0 ..< aMutArrImages.count
                {
                    let aDataImage: Data = UIImageJPEGRepresentation((aMutArrImages.object(at: aInt) as! NSDictionary).object(forKey: "photo")! as! UIImage, 0.5)!
                    
                    let aKeyOfPhoto = ((aMutArrImages.object(at: aInt) as! NSDictionary).object(forKey: "key") as! String)
                    multipartFormData.append(aDataImage, withName: ("\(aKeyOfPhoto)"), fileName: "img\(aInt+1).png", mimeType: "image/jpeg")

                }
                
                
        }, to: aStrFinalUrl,
           encodingCompletion: { encodingResult in
            
            switch encodingResult {
                
            case .success(let upload, _, _):
                
                upload.uploadProgress(closure: { (Progress) in
                    print("Upload Progress: \(Progress.fractionCompleted)")
                })
                
                upload.responseJSON { response in
                    
                    if let JSON = response.result.value {
                        print("JSON: \(JSON)")
                        
                        let aDictResponse = try! JSONSerialization.jsonObject(with: response.data!) as! NSDictionary
                        ref.getWebserviceResponse(aDictResponse: aDictResponse, aStrTag: aStrTag)
                    }
                }
                
            case .failure(let encodingError):
                //self.delegate?.showFailAlert()
                print(encodingError)
            }
            
        }
        )
        
    }
    
    func getWebserviceResponse(aDictResponse: NSDictionary, aStrTag: String)
    {
    }
    
}

