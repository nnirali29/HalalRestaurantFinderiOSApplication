//
//  HDCommonTextView.swift
//  HalalDlites
//
//  Created by user11 on 2/27/17.
//  Copyright © 2017 CCS Group. All rights reserved.
//

import Foundation
import UIKit

class HDCommonTextView: UITextView,UITextViewDelegate
{
    required init(coder aDecoder: NSCoder)
    {
        super.init(coder: aDecoder)!
        self.layer.cornerRadius = 5.0;
        self.layer.borderColor=(Constant.COLOR.aColor_Green).cgColor
        self.textColor=Constant.COLOR.aColor_Grey
        
        self.layer.borderWidth = 1.0
        
        
    }
}
