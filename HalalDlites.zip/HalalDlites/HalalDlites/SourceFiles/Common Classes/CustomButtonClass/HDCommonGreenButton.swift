//
//  RoundedCornerButton.swift
//  HalalDlites
//
//  Created by Yogesh on 30/01/17.
//  Copyright © 2017 CCS Group. All rights reserved.
//

import UIKit

class HDCommonGreenButton: UIButton
{
    override init(frame: CGRect)
    {
        super.init(frame: frame)
    }
   
   required init(coder aDecoder: NSCoder)
   {
        super.init(coder: aDecoder)!
    
        self.layer.cornerRadius = 5.0;
        self.backgroundColor = Constant.COLOR.aColor_Green
        self.tintColor = UIColor.white
        self.titleLabel!.textAlignment  = .center
        self.setTitleColor(Constant.COLOR.aColor_Grey, for: .normal)
    }
}
