//
//  HDCommonBottomBorderTxtField.swift
//  HalalDlites
//
//  Created by user11 on 4/7/17.
//  Copyright © 2017 CCS Group. All rights reserved.
//

import UIKit

class HDCommonBottomBorderTxtField: UITextField {

    override var tintColor: UIColor! {
        
        didSet {
            setNeedsDisplay()
        }
    }
    
    override func draw(_ rect: CGRect) {
        
        let startingPoint   = CGPoint(x: rect.minX, y: rect.maxY)
        let endingPoint     = CGPoint(x: rect.maxX, y: rect.maxY)
        
        let path = UIBezierPath()
        
        path.move(to: startingPoint)
        path.addLine(to: endingPoint)
        path.lineWidth = 2.0
    
        (Constant.COLOR.aColor_Grey).setStroke()
        path.stroke()
    }

}
