//
//  ProgressView.swift
//  HalalDlites
//
//  Created by user11 on 3/20/17.
//  Copyright © 2017 CCS Group. All rights reserved.
//

import Foundation
import UIKit

open class ProgressView {
    
    var viewContainew = UIView()
    var viewprogress = UIView()
    var activityIndicator = UIActivityIndicatorView()
    var lblLoading = UILabel()
    
    open class var shared: ProgressView {
        struct Static {
            static let instance: ProgressView = ProgressView()
        }
        return Static.instance
    }
    
    open func showProgressView(_ view: UIView) {
        
        viewContainew.frame = CGRect(x: 0, y: 0, width: view.bounds.width, height: view.bounds.height + 64)
        viewContainew.backgroundColor = UIColor(hex: 0xffffff, alpha: 0.3)
        
        viewprogress.frame = CGRect(x: 0, y: 0, width: 80, height: 80)
        viewprogress.center = viewContainew.center
        viewprogress.backgroundColor = UIColor(hex: 0x000000, alpha: 0.8)
        viewprogress.clipsToBounds = true
        viewprogress.layer.cornerRadius = 10
        
        activityIndicator.frame = CGRect(x: 0, y: 0, width: 40, height: 40)
        activityIndicator.activityIndicatorViewStyle = .white
        activityIndicator.center = CGPoint(x: viewprogress.bounds.width / 2, y: (viewprogress.bounds.height / 2) - 10)
        
        lblLoading.frame = CGRect(x: 0, y: 0, width: viewprogress.bounds.width, height: 20)
        lblLoading.center = CGPoint(x: viewprogress.bounds.width / 2, y: (viewprogress.bounds.height / 2) + 20)
        lblLoading.textColor = UIColor.white
        lblLoading.font = UIFont.systemFont(ofSize: 12)
        lblLoading.textAlignment = NSTextAlignment.center
        lblLoading.text = "Loading.."
        
        viewprogress.addSubview(lblLoading)
        viewprogress.addSubview(activityIndicator)
        viewContainew.addSubview(viewprogress)
        
        AppDelegate().getInstance().window?.addSubview(viewContainew)
        
        activityIndicator.startAnimating()
    }
    
    open func hideProgressView() {
        activityIndicator.stopAnimating()
        viewContainew.removeFromSuperview()
    }
}

extension UIColor {
    
    convenience init(hex: UInt32, alpha: CGFloat) {
        let red = CGFloat((hex & 0xFF0000) >> 16)/256.0
        let green = CGFloat((hex & 0xFF00) >> 8)/256.0
        let blue = CGFloat(hex & 0xFF)/256.0
        
        self.init(red: red, green: green, blue: blue, alpha: alpha)
    }
}
