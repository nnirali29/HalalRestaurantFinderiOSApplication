//
//  Constant.swift
//  HalalDlites
//
//  Created by Yogesh on 01/02/17.
//  Copyright © 2017 CCS Group. All rights reserved.
//

import UIKit
import Foundation

class Constant: NSObject
{
    struct structDeviceSize {
        
        static let IS_IOS10 = (Double(UIDevice.current.systemVersion)!) >= 10.0
        static let IS_IOS8 = (Double(UIDevice.current.systemVersion)!) == 8.0
        static let IS_IOS9 = (Double(UIDevice.current.systemVersion)!) >= 9.0
        
    }
    struct structCommanUrl
    {
        // Constant define here.
        
        static let kLiveUrl   =  "http://mmc-apps.com/dev/halal/api/v1_0/"
        static let kLocalUrl   =   "http://192.168.0.14/halal/api/v1_0/"
        
        static let kCommanUrl = kLiveUrl
    }
    
    struct structPageSize {
        
        //Constant page size
        
        static let size = 20
    }
    
    struct structDeviceScreen {
        
        static let kScreenWidth = UIScreen.main.bounds.size.width
        static let kScreenHeight = UIScreen.main.bounds.size.height
        
    }


    struct messages {
        
        static let kMailNotConfigure = "Please configure mail for device settings."
        static let kMsgDuration = 4.0
        static let KMsgNoInternet = "No Internet"
    }
   
    func CENTERNAVTITLE(_ navItem:  UINavigationItem, _ aStrNavTitle: String)
    {
        //  NAVIGATION TITLE CONSTANT
        let aLblNavTitle = UILabel(frame: CGRect(x: 0, y: 0, width: 100, height: 44))
        
        aLblNavTitle.textColor = UIColor(colorLiteralRed: 5.0/255.0, green: 143.0/255.0, blue: 114.0/255.0, alpha: 1.0);
        aLblNavTitle.textAlignment = NSTextAlignment.center
        aLblNavTitle.text = aStrNavTitle;
        aLblNavTitle.font = UIFont(name: "Roboto-Medium", size: 15)
        aLblNavTitle.backgroundColor = UIColor.white
        navItem.titleView = aLblNavTitle
    }
   
    func LEFTBACKBUTTON(navItem:UINavigationItem, ref:AnyObject)
    {
        //NAVIGATION LEFT BACK BUTTON
        let btnLeftArrow   = UIButton(type: .custom)
        btnLeftArrow.setImage(UIImage(named: "imgNavBackButton.png"), for: .normal)
        btnLeftArrow.addTarget(ref, action: Selector(("btnPopTapped")), for: .touchUpInside)
        btnLeftArrow.frame = CGRect(x: 0, y: 0, width: 13, height: 21)
      // self.navigationItem.barBtnLeftArrow = UIBarButtonItem(customView: btnLeftArrow)
       
        navItem.setLeftBarButton(UIBarButtonItem(customView: btnLeftArrow), animated: true)
    }
   
    func RIGHTMOREBUTTON(navItem:UINavigationItem, ref:AnyObject)
    {
        //NAVIGATION Right MORE BUTTON
        let btnRightMore   = UIButton(type: .custom)
        btnRightMore.setImage(UIImage(named: "More.png"), for: .normal)
        btnRightMore.addTarget(ref, action: Selector(("btnMoreTapped")), for: .touchUpInside)
        btnRightMore.frame = CGRect(x: 0, y: 15, width: 23, height: 6)
       
        navItem.setRightBarButton(UIBarButtonItem(customView: btnRightMore), animated: true)
    }
    
    func LEFTDRAWERBUTTON(navItem:UINavigationItem, ref:AnyObject)
    {
        //NAVIGATION LEFT DRAWER BUTTON
        let btnLeftdrawer   = UIButton(type: .custom)
        btnLeftdrawer.setImage(UIImage(named: "drawer.png"), for: .normal)
        btnLeftdrawer.addTarget(ref, action: Selector(("btnDrawerTapped")), for: .touchUpInside)
        btnLeftdrawer.frame = CGRect(x: 0, y: 0, width: 27, height: 20)
        // self.navigationItem.barBtnLeftArrow = UIBarButtonItem(customView: btnLeftArrow)
        
        navItem.setLeftBarButton(UIBarButtonItem(customView: btnLeftdrawer), animated: true)
    }
    func RIGHTSEARCHBUTTON(navItem:UINavigationItem, ref:AnyObject)
    {
        //NAVIGATION Right Search BUTTON
        let btnRightSearch   = UIButton(type: .custom)
        btnRightSearch.setImage(UIImage(named: "search.png"), for: .normal)
        btnRightSearch.addTarget(ref, action: Selector(("btnSearchTapped")), for: .touchUpInside)
        btnRightSearch.frame = CGRect(x: 0, y: 15, width: 21, height: 20)
        
        navItem.setRightBarButton(UIBarButtonItem(customView: btnRightSearch), animated: true)
    }
    
    func RIGHTSHAREBUTTON(navItem:UINavigationItem, ref:AnyObject)
    {
        //NAVIGATION Right Share BUTTON
        let btnRightShare   = UIButton(type: .custom)
        btnRightShare.setTitle("share", for: .normal)
        btnRightShare.setTitleColor(COLOR.aColor_LightGrey, for: .normal)
        btnRightShare.titleLabel?.font = FONT.medium.of(size: 13)
        btnRightShare.backgroundColor = COLOR.aColor_Green
        btnRightShare.layer.cornerRadius = 5
        btnRightShare.layer.borderWidth = 1
        btnRightShare.layer.borderColor = COLOR.aColor_Green.cgColor
        btnRightShare.addTarget(ref, action: Selector(("btnShareTapped")), for: .touchUpInside)
        btnRightShare.frame = CGRect(x: 0, y: 15, width: 40, height: 20)
        
        navItem.setRightBarButton(UIBarButtonItem(customView: btnRightShare), animated: true)
    }
    
    
    func RIGHTDONEBUTTON(navItem:UINavigationItem, ref:AnyObject)
    {
        //NAVIGATION Right done BUTTON
        let btnRightDone   = UIButton(type: .custom)
        btnRightDone.setTitle("Done", for: .normal)
        btnRightDone.setTitleColor(COLOR.aColor_Green, for: .normal)
        btnRightDone.titleLabel?.font = FONT.medium.of(size: 13)
        btnRightDone.addTarget(ref, action: Selector(("btnDoneTapped")), for: .touchUpInside)
        btnRightDone.frame = CGRect(x: 0, y: 15, width: 50, height: 30)
        
        navItem.setRightBarButton(UIBarButtonItem(customView: btnRightDone), animated: true)
    }
    func LEFTCANCELBUTTON(navItem:UINavigationItem, ref:AnyObject)
    {
        //NAVIGATION LEFT CANCEL BUTTON
        let btnLeftcancel   = UIButton(type: .custom)
        btnLeftcancel.setTitle("Cancel", for: .normal)
        btnLeftcancel.setTitleColor(COLOR.aColor_Green, for: .normal)
        btnLeftcancel.titleLabel?.font = FONT.medium.of(size: 13)
        btnLeftcancel.addTarget(ref, action: Selector(("btnCancelTapped")), for: .touchUpInside)
        btnLeftcancel.frame = CGRect(x: 0, y: 15, width: 50, height: 30)
        navItem.setLeftBarButton(UIBarButtonItem(customView: btnLeftcancel), animated: true)
    }

    struct COLOR
    {
        //  COLOR CONSTANT
        static let aColor_Green: UIColor = UIColor(colorLiteralRed: 5.0/255.0, green: 143.0/255.0, blue: 114.0/255.0, alpha: 1.0)
        static let aColor_Grey: UIColor = UIColor(colorLiteralRed: 159.0/255.0, green: 160.0/255.0, blue: 164.0/255.0, alpha: 1.0)
        static let aColor_LightGrey: UIColor = UIColor(colorLiteralRed: 224.0/255.0, green: 224.0/255.0, blue: 224.0/255.0, alpha: 1.0)
        static let aColor_Black: UIColor = UIColor(colorLiteralRed: 73.0/255.0, green: 73.0/255.0, blue: 73.0/255.0, alpha: 1.0)
    }
    
    enum FONT: String
    {
        //  FONT CONSTANT
        case Regular = "Roboto-Regular"
        case Bold = "Roboto-Bold"
        case medium = "Roboto-Medium"
        func of(size: CGFloat) -> UIFont
        {
            return UIFont(name: self.rawValue, size: size)!
        }
    }
    class func getInstance()
    {
        
    }
}
